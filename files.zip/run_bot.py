"""Run the bot.

  python run_bot.py replay [--speed 20] [--start 2015-01-01 --end 2020-12-31] [--source synthetic]
  python run_bot.py paper                      # forward paper trading, runs until stopped

Both modes write to the SQLite database so the dashboard can show them.
"""
import argparse
import json
import logging
import signal
import sys
from datetime import datetime
from threading import Event

import metrics
from clock import LiveClock, ReplayClock
from engine import Engine
from factory import load_config, make_limits, make_sim_broker, make_strategy
from feed import make_live_feed, make_replay_feed
from risk import RiskManager
from state import SqliteStore


def _stop_event():
    stop = Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: stop.set())
    return stop


def run_replay(cfg, args):
    for key in ("start", "end", "source"):
        if getattr(args, key):
            cfg["data"][key] = getattr(args, key)
    symbol = cfg["run"]["symbol"]
    feed = make_replay_feed(cfg)
    df = feed.df
    store = SqliteStore(cfg["run"]["db_path"])
    name = args.name or f"replay-{symbol}-{datetime.now():%Y%m%d-%H%M%S}"
    run_id = store.new_run(name, "replay", symbol, cfg)
    risk = RiskManager(make_limits(cfg, disabled=args.no_risk), store, run_id)
    stop = _stop_event()
    engine = Engine(symbol, feed, make_sim_broker(cfg), make_strategy(cfg), risk, store, run_id,
                    stop, cfg["run"]["rebalance_tolerance"])
    logging.info("replay %s: %s -> %s (%d bars), run id %d", symbol,
                 df.index[0].date(), df.index[-1].date(), len(df), run_id)
    try:
        engine.run(ReplayClock(df.index, args.speed))
    except Exception:
        store.set_status(run_id, "failed")
        raise
    store.set_status(run_id, "stopped" if stop.is_set() else "finished")

    eq = store.equity_series(run_id)
    if len(eq) > 1:
        close = df["Close"].reindex(eq.index)
        bench = eq.iloc[0] * close / close.iloc[0]
        print(f"\nRun {run_id} ({name})  trades: {len(store.fills_rows(run_id, 10**6))}")
        print(metrics.table(Strategy=eq, **{"Buy & hold": bench}))
    if risk.is_halted():
        print("\nNOTE: risk limits halted this run:", store.get_kv(run_id, "halted"))


def run_paper(cfg, args):
    symbol = cfg["run"]["symbol"]
    store = SqliteStore(cfg["run"]["db_path"])
    name = cfg["run"]["name"]
    run_id = store.find_run(name, "paper")
    resumed = run_id is not None
    broker = make_sim_broker(cfg)
    if resumed:
        old = json.loads(store.get_run(run_id)["config"])
        if old.get("strategy") != cfg["strategy"]:
            logging.warning("strategy settings differ from when this run started; "
                            "use a new [run].name for a clean test")
        state = store.get_kv(run_id, "broker")
        if state:
            broker.load_state(json.loads(state))
        store.set_status(run_id, "running")
        logging.info("resuming paper run %d (%s)", run_id, name)
    else:
        run_id = store.new_run(name, "paper", symbol, cfg)
        logging.info("new paper run %d (%s)", run_id, name)

    risk = RiskManager(make_limits(cfg), store, run_id)
    stop = _stop_event()
    engine = Engine(symbol, make_live_feed(cfg), broker, make_strategy(cfg), risk, store, run_id,
                    stop, cfg["run"]["rebalance_tolerance"])
    live = cfg["live"]
    try:
        engine.run(LiveClock(live["run_at"], live["timezone"]),
                   only_last_first=not resumed, raise_errors=False, log_ticks=True)
    finally:
        store.set_status(run_id, "stopped")
    logging.info("stopped")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="config.toml")
    sub = ap.add_subparsers(dest="mode", required=True)
    r = sub.add_parser("replay", help="run over historical dates as if live")
    r.add_argument("--speed", type=float, default=0, help="bars per second (0 = as fast as possible)")
    r.add_argument("--start"); r.add_argument("--end")
    r.add_argument("--source", choices=["yfinance", "csv", "synthetic"])
    r.add_argument("--name"); r.add_argument("--no-risk", action="store_true")
    sub.add_parser("paper", help="forward paper trading on a schedule")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        datefmt="%Y-%m-%d %H:%M:%S")
    cfg = load_config(args.config)
    (run_replay if args.mode == "replay" else run_paper)(cfg, args)


if __name__ == "__main__":
    sys.exit(main())
