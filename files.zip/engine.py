"""The one loop shared by replay, paper and (later) live trading.

   clock tick -> feed.bars_until(asof) -> for each NEW bar:
       fill queued orders at the open -> mark equity -> strategy -> risk -> queue order

Same code path in every mode; only the clock, feed and broker are swapped.
"""
import json
import logging

import pandas as pd

from state import fmt_ts, now_iso


class Engine:
    def __init__(self, symbol, feed, broker, strategy, risk, store, run_id, stop,
                 rebalance_tolerance=0.02):
        self.symbol, self.feed, self.broker = symbol, feed, broker
        self.strategy, self.risk, self.store = strategy, risk, store
        self.run_id, self.stop, self.tol = run_id, stop, rebalance_tolerance
        self.log = logging.getLogger("bot")
        self._fills_seen = 0
        risk.on_event = self.event

    def event(self, level, msg):
        self.log.log(getattr(logging, level, logging.INFO), msg)
        self.store.log(self.run_id, level, msg)

    def beat(self):
        self.store.set_kv(self.run_id, "heartbeat", now_iso())
        self.store.commit()

    # ------------------------------------------------------------------
    def _process_bar(self, df: pd.DataFrame, i: int):
        ts, bar, sym = df.index[i], df.iloc[i], self.symbol

        # 1) orders decided at the previous close fill at THIS bar's open
        self.broker.on_bar_open(ts, {sym: float(bar["Open"])})
        fills = getattr(self.broker, "fills", [])
        for f in fills[self._fills_seen:]:
            self.store.add_fill(self.run_id, fmt_ts(f.ts), f.symbol, f.qty, f.price, f.commission)
            side = "BUY" if f.qty > 0 else "SELL"
            self.event("INFO", f"{fmt_ts(f.ts)} FILL {side} {abs(f.qty)} {f.symbol} @ {f.price:.2f}")
        self._fills_seen = len(fills)

        # 2) mark to market at the close, update risk state
        close = float(bar["Close"])
        equity = self.broker.equity({sym: close})
        self.risk.update(equity)

        # 3) decide using data up to and including this close only
        pos = self.broker.get_position(sym)
        weight = self.strategy.target_weight(df["Close"].iloc[: i + 1])
        if weight is not None:
            desired = self.risk.clamp_target(int(equity * weight // close), pos, close)
            diff = desired - pos
            if diff and (desired == 0 or abs(diff) * close >= self.tol * equity):
                self.broker.place_market_order(sym, diff)
                side = "BUY" if diff > 0 else "SELL"
                self.event("INFO", f"{fmt_ts(ts)} ORDER {side} {abs(diff)} {sym} (fills at next open)")

        self.store.add_equity(self.run_id, fmt_ts(ts), equity, self.broker.get_cash(), pos, close)
        self.store.set_kv(self.run_id, "last_ts", fmt_ts(ts))
        if hasattr(self.broker, "state"):
            self.store.set_kv(self.run_id, "broker", json.dumps(self.broker.state()))
        self.store.set_kv(self.run_id, "heartbeat", now_iso())
        self.store.commit()

    def step(self, asof, only_last=False) -> int:
        """Process every bar newer than the last one handled. Returns how many."""
        df = self.feed.bars_until(asof)
        if df.empty:
            return 0
        last = self.store.get_kv(self.run_id, "last_ts")
        n = len(df)
        start = int(df.index.searchsorted(pd.Timestamp(last), side="right")) if last else 0
        if only_last and not last and n > 1:
            # Forward (paper) start: earlier bars are indicator history only.
            self.event("INFO", f"starting at {fmt_ts(df.index[-1])}; "
                               f"{n - 1} earlier bars used as history, not traded")
            start = n - 1
        done = 0
        for i in range(start, n):
            if self.stop.is_set():
                break
            self._process_bar(df, i)
            done += 1
        return done

    def run(self, clock, only_last_first=False, raise_errors=True, log_ticks=False):
        first = only_last_first
        for asof in clock.ticks(self.stop, self.beat):
            try:
                n = self.step(asof, only_last=first)
            except Exception as e:  # live mode: log and try again at the next tick
                if raise_errors:
                    raise
                self.event("ERROR", f"step failed: {e!r}")
                self.store.commit()
                continue
            first = False
            if n and log_ticks:
                self.event("INFO", f"processed {n} new bar(s) as of {fmt_ts(asof)}")
        self.store.commit()
