# Trading bot: replay, paper trading, dashboard

A small, headless bot you can run on a server (Proxmox VM/LXC), with a read-only web dashboard.
It ships with one teaching strategy (SMA crossover) that runs on **any mix of instruments at once**.
**It makes no claim of being profitable.**
The point is a clean pipeline where *replaying history* and *running live* use the same code.

    clock  ->  feed  ->  engine  ->  risk limits  ->  broker  ->  SQLite  ->  dashboard
    (when)    (data)    (the loop)   (final say)     (paper)     (state)    (read-only)

| File | Role |
|---|---|
| `engine.py` | The single loop used by every mode |
| `clock.py` | `ReplayClock` (walk through past dates, optionally paced) / `LiveClock` (weekdays after the close) |
| `feed.py`, `data.py` | Data sources: yfinance, CSV, synthetic. A feed only returns bars up to "now" |
| `strategy.py` | Decides a target weight per symbol (-1 = short, 0 = flat, 1 = invested) |
| `risk.py` | Position/order caps, shorting + leverage rules, one-bar loss and drawdown halts, pause flag |
| `broker.py` | `SimBroker` (paper): many symbols, fractional units, optional shorting. `SchwabBroker` is an empty placeholder on purpose |
| `state.py` | SQLite store (runs, equity, fills, events) |
| `run_bot.py` | Entry point: `replay` and `paper` modes |
| `ctl.py` | Pause / resume / clear halt / status / tail logs |
| `dashboard.py` | Read-only web UI (standard library only) |
| `control.py` | Local web panel: start/stop paper, run replays, live P&L across all symbols |
| `backtest.py`, `walkforward.py` | Quick in-memory backtest; train-then-test parameter checks |
| `test_bot.py` | Tests for look-ahead, restart-resume, risk limits, scheduling |

## What it can trade

Set `[run] symbols` in `config.toml` to any list of Yahoo Finance tickers:

    symbols = ["SPY", "AAPL", "BRK-B", "BTC-USD", "EURUSD=X", "GC=F", "^GSPC", "7203.T"]

| Instrument | Example tickers | Notes |
|---|---|---|
| Stocks, ETFs | `SPY` `AAPL` `BRK-B` | Prices are split/dividend adjusted |
| Crypto | `BTC-USD` `ETH-USD` | Trades 7 days a week; needs `fractional = true` |
| Forex | `EURUSD=X` | Traded as a price series; no swap/rollover costs |
| Futures | `ES=F` `GC=F` `CL=F` | Traded as a price series (see limits below) |
| Indices | `^GSPC` | Only useful as a signal/benchmark in real life, you can't buy an index directly |
| Foreign stocks | `7203.T` `0700.HK` | Prices are NOT converted to USD (see limits below) |

How several symbols work together:

- The account is split **equally** between the symbols, or by `[allocation]` (list every symbol; weights are normalised).
- Each symbol gets its **own copy of the strategy**, run on its own price history.
- Symbols can have different calendars. Crypto trades on weekends, stocks don't. A symbol is only decided on, and
  filled, on days it has a bar; on other days it is marked at its last close. Equity has one row per calendar date.
- Orders still fill at that symbol's **next open** (no look-ahead).
- `[risk] allow_short = true` + `[strategy] short = true` lets the SMA strategy go short instead of flat.
  `max_leverage` (default 1.0) caps total exposure; an order that would breach it is cut down, orders that reduce
  exposure always go through.
- The benchmark line is buy-and-hold of the same basket, rebalanced daily to the same split.

**Not supported, and not close to supported:** options (needs option chains, expiries, greeks, assignment),
margin interest, borrow fees on shorts, contract multipliers and expiries for futures, dividends on short positions,
intraday data, order types other than market.

**Known simplifications to keep in mind before trusting a result:**

- **Currency:** every price is treated as US dollars. A yen-priced stock at 3,000 is treated as $3,000, and London
  prices are in pence. Fine for % returns of one symbol, wrong when you mix currencies in one account.
- **Futures:** `ES=F` style tickers are continuous contracts that are *not* back-adjusted, so roll days show up as fake
  gaps. Quantity is "units of price", not contracts, so there is no margin or multiplier.
- **Shorting is optimistic:** no borrow cost, no hard-to-borrow list, no margin calls, and it can short anything.
- **Round-the-clock markets:** a daily bar for forex/futures can still be forming at 16:10 New York time. The default
  `run_at` is 17:10 for that reason. For crypto the feed drops the current (still forming) UTC day automatically.
- **Late starters:** a symbol with no data yet (e.g. a coin that launched in 2017, replayed from 2015) just sits in
  cash until its first bar; its share of the account is not given to the others.
- **Delisted / dead tickers:** if a symbol stops returning data, its last close is used forever.

## Quick start

    python3 -m venv venv && . venv/bin/activate
    pip install -r requirements.txt
    python test_bot.py                              # 24 tests
    python backtest.py --synthetic                  # plumbing check on fake data
    python run_bot.py replay --source synthetic     # saved to SQLite
    python dashboard.py                             # http://127.0.0.1:8080

With real data (needs internet): set `[data] source = "yfinance"` in `config.toml`, or use `--source csv`
with `data.csv_path` (first column date, then Open/High/Low/Close). With several symbols, `csv_path` is
`"data/{symbol}.csv"` or a folder (`folder/SYMBOL.csv`).

    python backtest.py --yf SPY,QQQ,BTC-USD,EURUSD=X,GC=F --start 2015-01-01 --fractional
    python backtest.py --yf SPY,TLT --short                 # long/short SMA
    python run_bot.py replay --symbols SPY,BTC-USD          # one-off replay with other symbols

## Modes

**Replay**: runs the engine over historical dates as if it were live. `--speed 20` plays 20 bars/second
so you can watch the dashboard fill in; `--speed 0` runs flat out. The first `slow` bars are indicator
warm-up. Every replay is saved as its own run.

**Paper**: forward test on live data with the simulated broker. It sleeps until `[live] run_at`
(default 16:10 New York, weekdays), pulls daily bars, and processes any new ones. On the first start,
earlier bars are used only as indicator history and are not traded. Restarting resumes the same run
(matched by `[run] name`) with its cash, positions and pending orders restored. Use a new `name` for a clean test.
Before `run_at`, today's still-forming bar is ignored.

## How it avoids fooling you

- A decision at today's close fills at tomorrow's open (no look-ahead). Tests cover this.
- Feeds can't return future bars, so strategies can't peek.
- Commission and slippage are modeled; set them realistically.
- Always compare to buy-and-hold (shown in the dashboard and replay summary).
- `walkforward.py` picks parameters on a training window and scores them on the *next* window only.

## Risk limits (`[risk]` in config.toml, 0 disables)

`max_position_value` (per symbol, long or short), `max_order_value` / `max_order_shares` (largest single order that
*adds* exposure; closing is never capped; prefer the $ one when symbols have very different prices),
`max_daily_loss_pct` and `max_drawdown_pct` (account-wide; these **halt** the run, and `flatten_on_halt` closes
everything, shorts included), `allow_short`, `max_leverage`, plus a manual pause.
A halt is sticky until you clear it. Replays can hit the drawdown halt too; use `--no-risk` to disable.

    python ctl.py status            # latest paper run
    python ctl.py pause             # no new orders from the next bar on
    python ctl.py resume
    python ctl.py clear-halt
    python ctl.py tail -n 50

## Dashboard

Read-only: it opens the database read-only and has no endpoints that change anything.
Shows status (running / stale / paused / halted), equity vs buy-and-hold, drawdown, a holdings table
(long/short, value, % of equity), fills, events, and a run picker. It refreshes every 5 seconds.

    DASH_PASSWORD=choose-something python dashboard.py --host 0.0.0.0

It refuses to bind to a non-local address without `DASH_PASSWORD`. Basic auth over plain HTTP is
acceptable on localhost or inside a VPN (WireGuard/Tailscale). **Never expose it to the public internet.**

## Running it on a server (Proxmox VM or LXC)

    sudo useradd -r -m -d /opt/trading_bot trader
    # copy this folder to /opt/trading_bot, then as that user:
    python3 -m venv venv && venv/bin/pip install -r requirements.txt && mkdir -p data
    sudo cp deploy/*.service /etc/systemd/system/
    echo 'DASH_PASSWORD=choose-something' | sudo tee /etc/trading_bot.env && sudo chmod 600 /etc/trading_bot.env
    sudo systemctl daemon-reload && sudo systemctl enable --now trading-bot trading-dashboard
    journalctl -u trading-bot -f

Make sure the clock is synced (chrony/NTP) and back up `data/bot.db` (it is your account history).
Keep the dashboard on localhost or your VPN interface address.

## Going live with Schwab (not built - read this first)

Schwab's API has **no paper mode**, so everything sent through it is real. `SchwabBroker` is empty
on purpose. If you build it (with `schwab-py` or `schwabdev`), implement `get_cash`, `get_position`,
`place_market_order` and wrap it with, at minimum:

1. a **dry-run flag that defaults to on** and only logs the orders it would send;
2. the existing `RiskManager` limits, set small;
3. a live data feed (also not built) so the strategy sees the same data it was tested on;
4. alerting when the OAuth token expires (the refresh token lapses periodically, so re-auth is manual), and a check that broker positions match the bot's records at startup.

Run paper for a good while first, then start with tiny size.

## What has and hasn't been tested

Tested here: the engine, risk limits, pause/halt, restart-resume (single and multi-symbol), mixed stock/crypto
calendars, fractional units, shorting, the leverage cap, the scheduling logic, replay into SQLite, paper mode
start/stop/resume against CSVs for two symbols, `ctl.py`, the dashboard's API, the control panel's live-equity maths,
and a syntax check of both pages' JavaScript. Single-symbol results are identical to the previous version.
**Not tested:** the yfinance feed for non-stock tickers (no Yahoo access in my sandbox, so crypto/forex/futures
data quirks are unverified), the systemd units, how the dashboard and control pages actually render in a browser,
and anything involving Schwab. Try those yourself and expect small fixes.

## Caveats

This is educational software, not financial advice. A backtest, even a careful one, can't promise future results.
Daily bars hide intraday moves; taxes and dividends are ignored unless your data is adjusted; spreading money over
more symbols is not the same as being safer, and simulated shorts and leverage-free futures are flattering; tuning
parameters to look good in-sample is overfitting. Mind data-vendor terms for yfinance (unofficial, can break).
