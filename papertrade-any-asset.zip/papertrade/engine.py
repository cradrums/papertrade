"""The one loop shared by replay, paper and (later) live trading.

   clock tick -> feed.bars_until(asof) -> for each NEW date (union of all symbols' bar dates):
       fill queued orders at that day's opens -> mark equity -> strategy per symbol -> risk -> queue orders

Same code path in every mode; only the clock, feed and broker are swapped.

Several symbols: the account is split between them (equally, or by [allocation]) and each symbol runs
its own strategy instance on its own bars. Symbols may have different calendars (crypto trades on
weekends, stocks don't): a symbol is only decided on, and only filled, on dates when it has a bar;
on other dates it is simply marked at its last close.
"""
import copy
import json
import logging

import pandas as pd

from state import fmt_qty, fmt_ts, now_iso


class Engine:
    def __init__(self, symbols, feed, broker, strategy, risk, store, run_id, stop,
                 rebalance_tolerance=0.02, weights=None):
        self.symbols = [symbols] if isinstance(symbols, str) else list(symbols)
        self.feed, self.broker = feed, broker
        self.risk, self.store = risk, store
        self.run_id, self.stop, self.tol = run_id, stop, rebalance_tolerance
        # `strategy` is either {symbol: strategy} or one strategy object that is copied per symbol
        if isinstance(strategy, dict):
            self.strategies = dict(strategy)
        else:
            self.strategies = {s: copy.deepcopy(strategy) for s in self.symbols}
        w = {s: float((weights or {}).get(s, 1.0)) for s in self.symbols}
        total = sum(w.values())
        self.alloc = {s: v / total for s, v in w.items()}   # share of the account per symbol
        self.lev = float(getattr(risk.limits, "max_leverage", 0) or 1.0)
        self.log = logging.getLogger("bot")
        self._fills_seen = 0
        self._prev_marks: dict = {}
        self._bench = None
        risk.on_event = self.event

    def event(self, level, msg):
        self.log.log(getattr(logging, level, logging.INFO), msg)
        self.store.log(self.run_id, level, msg)

    def beat(self):
        self.store.set_kv(self.run_id, "heartbeat", now_iso())
        self.store.commit()

    # ------------------------------------------------------------------
    @staticmethod
    def _marks_at(frames: dict, ts) -> dict:
        """Last close at or before ts for every symbol that has data by then."""
        out = {}
        for s, df in frames.items():
            n = int(df.index.searchsorted(ts, side="right"))
            if n:
                out[s] = float(df["Close"].iloc[n - 1])
        return out

    def _update_bench(self, marks: dict) -> float:
        """Buy-and-hold benchmark: the symbol's own close for one symbol; for several, an index that
        follows the allocation, rebalanced daily. Stored in the equity table's `close` column."""
        if self._bench is None:
            v = self.store.get_kv(self.run_id, "bench")
            self._bench = float(v) if v else None
        first = next(s for s in self.symbols if s in marks)
        if self._bench is None:
            self._bench = marks[first]
        else:
            have = [s for s in self.symbols if s in marks and self._prev_marks.get(s)]
            wsum = sum(self.alloc[s] for s in have)
            if wsum > 0:
                r = sum(self.alloc[s] * (marks[s] / self._prev_marks[s] - 1) for s in have) / wsum
                self._bench *= 1 + r
        self.store.set_kv(self.run_id, "bench", self._bench)
        return self._bench

    def _process_date(self, ts, frames: dict):
        n_bars, bars = {}, {}
        for s, df in frames.items():
            n = int(df.index.searchsorted(ts, side="right"))
            if n:
                n_bars[s] = n
                if df.index[n - 1] == ts:
                    bars[s] = df.iloc[n - 1]

        # 1) orders decided at a symbol's previous close fill at THIS bar's open
        self.broker.on_bar_open(ts, {s: float(b["Open"]) for s, b in bars.items()})
        fills = getattr(self.broker, "fills", [])
        for f in fills[self._fills_seen:]:
            self.store.add_fill(self.run_id, fmt_ts(f.ts), f.symbol, f.qty, f.price, f.commission)
            side = "BUY" if f.qty > 0 else "SELL"
            self.event("INFO", f"{fmt_ts(f.ts)} FILL {side} {fmt_qty(f.qty)} {f.symbol} @ {f.price:.2f}")
        self._fills_seen = len(fills)

        # 2) mark to market at the close (symbols without a bar today keep their last close)
        marks = {s: float(frames[s]["Close"].iloc[n - 1]) for s, n in n_bars.items()}
        equity = self.broker.equity(marks)
        self.risk.update(equity)

        # 3) decide per symbol, using data up to and including this close only
        for s in self.symbols:
            if s not in bars:
                continue
            weight = self.strategies[s].target_weight(frames[s]["Close"].iloc[: n_bars[s]])
            if weight is None:
                continue
            if equity <= 0:
                weight = 0.0
            weight = max(-self.lev, min(self.lev, float(weight)))
            close, pos = marks[s], self.broker.get_position(s)
            raw = equity * self.alloc[s] * weight / close
            desired = self.broker.round_qty(self.risk.clamp_target(raw, pos, close))
            diff = desired - pos
            if diff and (desired == 0 or abs(diff) * close >= self.tol * equity):
                self.broker.place_market_order(s, diff)
                side = "BUY" if diff > 0 else "SELL"
                self.event("INFO", f"{fmt_ts(ts)} ORDER {side} {fmt_qty(diff)} {s} (fills at next open)")

        bench = self._update_bench(marks)
        self._prev_marks = marks
        first_pos = self.broker.get_position(self.symbols[0])
        self.store.add_equity(self.run_id, fmt_ts(ts), equity, self.broker.get_cash(), first_pos, bench)
        self.store.set_kv(self.run_id, "last_ts", fmt_ts(ts))
        self.store.set_kv(self.run_id, "holdings", json.dumps(
            {s: [self.broker.get_position(s), marks[s]] for s in self.symbols if s in marks}))
        if hasattr(self.broker, "state"):
            self.store.set_kv(self.run_id, "broker", json.dumps(self.broker.state()))
        self.store.set_kv(self.run_id, "heartbeat", now_iso())
        self.store.commit()

    def step(self, asof, only_last=False) -> int:
        """Process every date newer than the last one handled. Returns how many."""
        frames = {s: df for s, df in self.feed.bars_until(asof).items() if s in self.strategies and not df.empty}
        if not frames:
            return 0
        last = self.store.get_kv(self.run_id, "last_ts")
        last_ts = pd.Timestamp(last) if last else None

        new = set()
        for df in frames.values():
            i = 0 if last_ts is None else int(df.index.searchsorted(last_ts, side="right"))
            new.update(df.index[i:])
        dates = sorted(new)
        if not dates:
            return 0
        if only_last and last_ts is None and len(dates) > 1:
            # Forward (paper) start: earlier bars are indicator history only.
            self.event("INFO", f"starting at {fmt_ts(dates[-1])}; "
                               f"{len(dates) - 1} earlier bars used as history, not traded")
            dates = dates[-1:]

        # prices as of the last handled date: the benchmark's reference and the broker's leverage check
        self._prev_marks = self._marks_at(frames, last_ts) if last_ts is not None else {}
        if self._prev_marks:
            self.broker.mark(self._prev_marks)

        done = 0
        for ts in dates:
            if self.stop.is_set():
                break
            self._process_date(ts, frames)
            done += 1
        return done

    def run(self, clock, only_last_first=False, raise_errors=True, log_ticks=False):
        first = only_last_first
        for asof in clock.ticks(self.stop, self.beat):
            try:
                n = self.step(asof, only_last=first)
            except Exception as e:  # live mode: log and try again at the next tick
                if raise_errors:
                    raise
                self.event("ERROR", f"step failed: {e!r}")
                self.store.commit()
                continue
            first = False
            if n and log_ticks:
                self.event("INFO", f"processed {n} new bar(s) as of {fmt_ts(asof)}")
        self.store.commit()
