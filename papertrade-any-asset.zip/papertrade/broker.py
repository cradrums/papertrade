"""Broker interface + a simulated (paper) broker.

The engine only talks to the `Broker` interface. To trade for real later you
write a SchwabBroker with the same methods and swap it in.

The simulator is deliberately simple and instrument-agnostic: every symbol is a
price series, a position is a (possibly fractional, possibly negative) number of
units, and equity = cash + sum(units * price). That is enough for stocks, ETFs,
crypto, forex pairs and futures-as-price-series. It does NOT model contract
multipliers, margin interest, borrow fees, option greeks or currency conversion.
"""
import math
from abc import ABC, abstractmethod
from dataclasses import dataclass


class Broker(ABC):
    @abstractmethod
    def get_cash(self) -> float: ...

    @abstractmethod
    def get_position(self, symbol: str) -> float:
        """Units held. Negative means short (only possible when shorting is enabled)."""

    @abstractmethod
    def place_market_order(self, symbol: str, qty: float) -> None:
        """qty > 0 buys, qty < 0 sells (or sells short)."""

    def round_qty(self, qty: float) -> float:
        """Round toward zero to the smallest tradable lot (whole units by default)."""
        return math.trunc(qty)

    def mark(self, prices: dict) -> None:
        """Tell the broker the latest known prices (the simulator uses them for its leverage check)."""

    def on_bar_open(self, ts, open_prices: dict) -> None:
        """Hook called at the start of each bar (the simulator fills orders here)."""

    def equity(self, prices: dict) -> float:
        return self.get_cash() + sum(self.get_position(s) * p for s, p in prices.items())


@dataclass
class Fill:
    ts: object
    symbol: str
    qty: float
    price: float
    commission: float


def _split(pos: float, qty: float):
    """Split an order into the part that closes existing exposure and the part that opens new exposure."""
    if pos == 0 or (pos > 0) == (qty > 0):
        return 0.0, qty
    sign = 1.0 if pos > 0 else -1.0
    closing = -sign * min(abs(qty), abs(pos))
    return closing, qty - closing


class SimBroker(Broker):
    """Paper broker. Orders placed at bar t's close fill at that symbol's next bar open.

    The one-bar delay is deliberate: it prevents look-ahead bias (you cannot
    trade at a price you only learned after the bar closed).

    Rules:
      * Orders that reduce exposure always fill; orders that add exposure are cut down so that
        gross exposure (sum of |units * price|) never exceeds `max_leverage * equity`.
        With the defaults (no shorting, 1.0x) that is exactly "you can't spend cash you don't have".
      * Shorting only works when allow_short=True. Proceeds go to cash; equity stays cash + units*price.
      * fractional=True allows units down to 1e-6 (needed for crypto, high-priced tickers, forex).
    """

    DECIMALS = 6

    def __init__(self, cash=100_000.0, commission_per_trade=0.0, slippage_bps=1.0,
                 allow_short=False, max_leverage=1.0, fractional=False):
        self.cash = float(cash)
        self.commission = float(commission_per_trade)
        self.slip = slippage_bps / 10_000.0
        self.allow_short = bool(allow_short)
        self.max_leverage = float(max_leverage) if max_leverage else 1.0
        self.fractional = bool(fractional)
        self.positions: dict[str, float] = {}
        self.fills: list[Fill] = []
        self.marks: dict[str, float] = {}
        self._pending: list[tuple[str, float]] = []

    # --- Broker interface ---
    def get_cash(self):
        return self.cash

    def get_position(self, symbol):
        return self.positions.get(symbol, 0)

    def place_market_order(self, symbol, qty):
        qty = self.round_qty(qty)
        if qty:
            self._pending.append((symbol, qty))

    def round_qty(self, qty):
        if self.fractional:
            f = 10 ** self.DECIMALS
            return math.trunc(qty * f) / f
        return math.trunc(qty)

    def mark(self, prices):
        self.marks.update({s: float(p) for s, p in prices.items()})

    def on_bar_open(self, ts, open_prices):
        """Fill queued orders at this bar's open. Orders for a symbol with no bar today keep waiting."""
        self.mark(open_prices)
        ready = []
        for symbol, qty in self._pending:
            (ready if symbol in open_prices else []).append((symbol, qty))
        self._pending = [o for o in self._pending if o[0] not in open_prices]
        # orders that only reduce exposure go first, so they free room for the ones that add exposure
        ready.sort(key=lambda o: _split(self.get_position(o[0]), o[1])[1] != 0)
        for symbol, qty in ready:
            self._fill(ts, symbol, qty, open_prices[symbol])

    def _fill(self, ts, symbol, qty, open_px):
        pos = self.get_position(symbol)
        closing, opening = _split(pos, qty)
        if opening < 0 and not self.allow_short:
            opening = 0.0                                   # no shorting
        sign = 1.0 if qty > 0 else -1.0
        px = open_px * (1 + sign * self.slip)               # buys pay up, sells receive less
        if opening:
            opening = sign * self._room(symbol, pos, closing, px, open_px, abs(opening))
        fill = closing + opening
        if fill == 0:
            return
        self.cash -= fill * px + self.commission
        new = round(pos + fill, 9)
        if abs(new) < 1e-9:
            self.positions.pop(symbol, None)
        else:
            self.positions[symbol] = new if self.fractional else int(new)
        self.fills.append(Fill(ts, symbol, fill, px, self.commission))

    def _room(self, symbol, pos, closing, px, mark, want):
        """Largest opening size (<= want) that keeps gross exposure within max_leverage * equity."""
        others = [(s, q) for s, q in self.positions.items() if s != symbol and s in self.marks]
        others_val = sum(q * self.marks[s] for s, q in others)
        others_gross = sum(abs(q) * self.marks[s] for s, q in others)
        pos1 = pos + closing
        cash1 = self.cash - closing * px - self.commission
        equity1 = cash1 + others_val + pos1 * mark
        gross1 = others_gross + abs(pos1) * mark
        room = self.max_leverage * equity1 - gross1
        if room <= 0:
            return 0.0
        # each extra unit adds `mark` of gross and costs (px - mark) in slippage on top of its value
        m_max = room / (mark * (1 + self.max_leverage * self.slip))
        return abs(self.round_qty(min(want, m_max)))

    # --- persistence (so a restarted paper run keeps its account) ---
    def state(self) -> dict:
        return {"cash": self.cash, "positions": self.positions, "pending": self._pending}

    def load_state(self, s: dict) -> None:
        conv = float if self.fractional else int
        self.cash = float(s["cash"])
        self.positions = {k: conv(v) for k, v in s["positions"].items() if float(v) != 0}
        self._pending = [(a, conv(b)) for a, b in s.get("pending", [])]


class SchwabBroker(Broker):
    """Placeholder for live trading. Intentionally NOT implemented.

    Schwab's API has no paper mode, so everything sent through it is real.
    See README ("Going live") for what to build and which guards to add first.
    """

    def get_cash(self):
        raise NotImplementedError

    def get_position(self, symbol):
        raise NotImplementedError

    def place_market_order(self, symbol, qty):
        raise NotImplementedError
