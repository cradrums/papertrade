"""Walk-forward test: choose parameters on a training window, then judge them
on the NEXT window the choice never saw. Repeat across the history.

  python walkforward.py --synthetic
  python walkforward.py --yf SPY --start 2000-01-01 --train-years 5 --test-years 1 \
      --fast 10,20,50 --slow 100,150,200
"""
import argparse
import itertools

import pandas as pd

import metrics
from backtest import buy_and_hold, run_backtest
from broker import SimBroker
from data import load_csv, load_yfinance, synthetic
from strategy import SmaCrossStrategy


def score(equity):
    s = metrics.compute(equity)["sharpe"]
    return s if s == s else -9.0  # NaN -> very bad


def main():
    p = argparse.ArgumentParser()
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--csv"); src.add_argument("--yf", metavar="SYMBOL")
    src.add_argument("--synthetic", action="store_true")
    p.add_argument("--start", default="2000-01-01")
    p.add_argument("--train-years", type=int, default=4)
    p.add_argument("--test-years", type=int, default=1)
    p.add_argument("--fast", default="10,20,50")
    p.add_argument("--slow", default="100,150,200")
    p.add_argument("--cash", type=float, default=100_000)
    p.add_argument("--slippage-bps", type=float, default=1.0)
    a = p.parse_args()

    df = load_csv(a.csv) if a.csv else load_yfinance(a.yf, a.start) if a.yf else synthetic()
    grid = [(f, s) for f, s in itertools.product(map(int, a.fast.split(",")), map(int, a.slow.split(",")))
            if f < s]
    max_slow = max(s for _, s in grid)
    train, test = pd.DateOffset(years=a.train_years), pd.DateOffset(years=a.test_years)

    def bt(window, params, cash=a.cash):
        eq, _ = run_backtest(window, "X", SmaCrossStrategy(*params), SimBroker(cash, 0, a.slippage_bps))
        return eq

    rows, oos_growth, bh_growth = [], 1.0, 1.0
    t0 = df.index[0]
    while t0 + train + test <= df.index[-1] + pd.Timedelta(days=1):
        t1, t2 = t0 + train, t0 + train + test
        train_df = df.loc[t0:t1 - pd.Timedelta(days=1)]
        best = max(grid, key=lambda g: score(bt(train_df, g)))
        # Test window gets `slow` bars of history in front so the averages are warm
        pos = df.index.searchsorted(t1)
        test_df = df.iloc[max(0, pos - best[1]): df.index.searchsorted(t2)]
        eq = bt(test_df, best).loc[t1:]
        bh = buy_and_hold(test_df.loc[t1:], a.cash)
        if len(eq) > 1:
            r, b = eq.iloc[-1] / eq.iloc[0] - 1, bh.iloc[-1] / bh.iloc[0] - 1
            oos_growth *= 1 + r; bh_growth *= 1 + b
            rows.append({"test window": f"{t1.date()}..{(t2 - pd.Timedelta(days=1)).date()}",
                         "chosen fast/slow": f"{best[0]}/{best[1]}",
                         "strategy": f"{r:+.1%}", "buy&hold": f"{b:+.1%}"})
        t0 += test

    if not rows:
        raise SystemExit("not enough data for even one train+test window")
    print(pd.DataFrame(rows).to_string(index=False))
    print(f"\nChained out-of-sample: strategy {oos_growth - 1:+.1%}   buy&hold {bh_growth - 1:+.1%}")
    print("(Parameters were picked only from data BEFORE each test window.)")


if __name__ == "__main__":
    main()
