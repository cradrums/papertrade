"""Clocks decide WHEN the engine looks at the data.

ReplayClock walks through historical bar dates (optionally paced so you can
watch it on the dashboard). LiveClock wakes once per weekday after the close.
Both yield an 'as-of' date: the engine only sees bars up to that date.
"""
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import pandas as pd


class ReplayClock:
    def __init__(self, timestamps, speed: float = 0.0):
        """speed = bars per second; 0 means as fast as possible."""
        self.timestamps, self.speed = list(timestamps), float(speed)

    def ticks(self, stop, heartbeat=None):
        for ts in self.timestamps:
            if stop.is_set():
                return
            yield ts
            if self.speed > 0 and stop.wait(1.0 / self.speed):
                return


class LiveClock:
    def __init__(self, run_at="16:10", tz="America/New_York", run_immediately=True):
        h, m = (int(x) for x in run_at.split(":"))
        self.h, self.m, self.tz = h, m, ZoneInfo(tz)
        self.run_immediately = run_immediately

    def _target(self, day):
        return datetime(day.year, day.month, day.day, self.h, self.m, tzinfo=self.tz)

    def asof(self, now=None):
        """Last session date that can be considered complete.

        Before run_at, today's (partial) bar is excluded - otherwise a daily bar
        that is still forming would be treated as final.
        """
        now = now or datetime.now(self.tz)
        d = now.date() if now >= self._target(now.date()) else now.date() - timedelta(days=1)
        return pd.Timestamp(d)

    def next_run(self, now):
        day = now.date()
        if now >= self._target(day):
            day += timedelta(days=1)
        while day.weekday() >= 5:  # skip Sat/Sun (market holidays just yield no new bar)
            day += timedelta(days=1)
        return self._target(day)

    def ticks(self, stop, heartbeat=None):
        if self.run_immediately:
            yield self.asof()
        while not stop.is_set():
            target = self.next_run(datetime.now(self.tz))
            while not stop.is_set():
                remaining = (target - datetime.now(self.tz)).total_seconds()
                if remaining <= 0:
                    break
                if heartbeat:
                    heartbeat()
                stop.wait(min(60.0, remaining))
            if stop.is_set():
                return
            yield self.asof()
