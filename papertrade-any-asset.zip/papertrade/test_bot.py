"""Run with:  python test_bot.py   (or: pytest test_bot.py)"""
import json
import tempfile
from datetime import datetime
from pathlib import Path
from threading import Event
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from broker import SimBroker
from clock import LiveClock, ReplayClock
from data import csv_path_for, synthetic
from engine import Engine
from factory import normalize, parse_symbols
from feed import CsvFeed, FrameFeed
from risk import RiskLimits, RiskManager
from state import MemoryStore, SqliteStore
from strategy import SmaCrossStrategy


def raises(exc, fn, *args):
    """Tiny stand-in for pytest.raises so the tests run with no extra packages."""
    try:
        fn(*args)
    except exc:
        return True
    raise AssertionError(f"{fn.__name__}{args} should have raised {exc.__name__}")


class AlwaysLong:
    """Goes long at bar index 5 (only looking at data up to that bar)."""
    def target_weight(self, closes):
        return 1.0 if len(closes) >= 6 else None


class Const:
    """Always asks for the same weight (after a short warm-up)."""
    def __init__(self, w):
        self.w = w
    def target_weight(self, closes):
        return self.w if len(closes) >= 6 else None


def make_engine(df, strategy, limits=None, store=None, run_id=1, broker=None):
    store = store or MemoryStore()
    risk = RiskManager(limits or RiskLimits(), store, run_id)
    broker = broker or SimBroker(100_000, 0, 0)
    return Engine("X", FrameFeed({"X": df}), broker, strategy, risk, store, run_id, Event(), 0.0), store, broker


def make_multi(frames, strategy, limits=None, broker=None, weights=None, tol=0.0):
    store = MemoryStore()
    risk = RiskManager(limits or RiskLimits(), store, 1)
    broker = broker or SimBroker(100_000, 0, 0)
    eng = Engine(list(frames), FrameFeed(frames), broker, strategy, risk, store, 1, Event(), tol, weights)
    dates = sorted(set().union(*[f.index for f in frames.values()]))
    return eng, store, broker, dates


def flat_frame(prices, start="2020-01-01", freq="D"):
    idx = pd.date_range(start, periods=len(prices), freq=freq)
    p = np.asarray(prices, dtype=float)
    return pd.DataFrame({"Open": p, "High": p, "Low": p, "Close": p}, index=idx)


def test_fills_at_next_open_not_same_bar():
    df = synthetic(30, seed=1)
    eng, store, broker = make_engine(df, AlwaysLong())
    eng.run(ReplayClock(df.index))
    first = broker.fills[0]
    assert first.ts == df.index[6], "decision at bar 5's close must fill on bar 6"
    assert abs(first.price - df["Open"].iloc[6]) < 1e-9, "fill price must be bar 6's open"


def test_strategy_never_sees_future():
    df = synthetic(300, seed=2)
    seen = []
    class Spy:
        def target_weight(self, closes):
            seen.append((len(closes), closes.index[-1]))
            return 0.0
    eng, _, _ = make_engine(df, Spy())
    eng.run(ReplayClock(df.index))
    for n, last in seen:
        assert last == df.index[n - 1], "history passed to strategy must end at the current bar"


def test_resume_matches_continuous_run():
    df = synthetic(700, seed=3)
    strat = lambda: SmaCrossStrategy(20, 60)
    # continuous
    eng, store, _ = make_engine(df, strat())
    eng.run(ReplayClock(df.index))
    expected = store.equity_series().iloc[-1]

    # "live": CSV grows over time, process restarts in between
    tmp = Path(tempfile.mkdtemp()); csv = tmp / "px.csv"; db = tmp / "t.db"
    df.iloc[:450].rename_axis("Date").to_csv(csv)
    st = SqliteStore(db); rid = st.new_run("t", "paper", "X", {})
    risk = RiskManager(RiskLimits(), st, rid)
    e1 = Engine("X", CsvFeed({"X": str(csv)}), SimBroker(100_000, 0, 0), strat(), risk, st, rid, Event(), 0.0)
    e1.step(df.index[449])
    st.close()

    df.rename_axis("Date").to_csv(csv)                     # more data arrives; process restarts
    st = SqliteStore(db)
    broker = SimBroker(100_000, 0, 0); broker.load_state(json.loads(st.get_kv(rid, "broker")))
    risk = RiskManager(RiskLimits(), st, rid)
    e2 = Engine("X", CsvFeed({"X": str(csv)}), broker, strat(), risk, st, rid, Event(), 0.0)
    n = e2.step(df.index[-1])
    assert n == 250, f"should process only the new bars, got {n}"
    got = st.equity_series(rid).iloc[-1]
    assert abs(got - expected) < 1e-6, (got, expected)
    assert len(st.equity_series(rid)) == 700, "no bar processed twice or skipped"


def test_paper_start_only_trades_forward():
    df = synthetic(300, seed=4)
    eng, store, broker = make_engine(df, SmaCrossStrategy(20, 60))
    eng.step(df.index[-1], only_last=True)
    assert len(store.eq) == 1, "history bars must not be traded"


def test_drawdown_halt_flattens_and_stays_flat():
    idx = pd.bdate_range("2020-01-01", periods=60)
    close = np.concatenate([np.linspace(100, 110, 20), np.linspace(110, 60, 40)])
    df = pd.DataFrame({"Open": close, "High": close, "Low": close, "Close": close}, index=idx)
    eng, store, broker = make_engine(df, AlwaysLong(), RiskLimits(max_drawdown_pct=20))
    eng.run(ReplayClock(df.index))
    assert store.get_kv(1, "halted"), "drawdown limit should have halted the run"
    assert broker.get_position("X") == 0, "flatten_on_halt should sell everything"


def test_pause_blocks_orders():
    df = synthetic(30, seed=5)
    store = MemoryStore(); store.set_kv(1, "paused", "1")
    eng, _, broker = make_engine(df, AlwaysLong(), store=store)
    eng.run(ReplayClock(df.index))
    assert not broker.fills, "paused bot must not trade"


def test_position_and_order_caps():
    df = synthetic(30, seed=6)
    lim = RiskLimits(max_position_value=10_000, max_order_shares=50)
    eng, _, broker = make_engine(df, AlwaysLong(), lim)
    eng.run(ReplayClock(df.index))
    assert broker.fills, "should have bought something"
    assert all(f.qty <= 50 for f in broker.fills), "every single BUY is capped at max_order_shares"
    assert len(broker.fills) > 1, "a capped position is built up over several bars"
    assert broker.get_position("X") * df["Close"].iloc[-1] <= 10_000 * 1.05, "position value cap"


def test_live_clock_schedule_and_partial_bar_guard():
    c = LiveClock("16:10", "America/New_York")
    tz = ZoneInfo("America/New_York")
    # Wednesday 10:00 -> today's bar is still forming, use Tuesday's
    assert c.asof(datetime(2026, 10, 21, 10, 0, tzinfo=tz)) == pd.Timestamp("2026-10-20")
    # Wednesday 16:30 -> today's bar is complete
    assert c.asof(datetime(2026, 10, 21, 16, 30, tzinfo=tz)) == pd.Timestamp("2026-10-21")
    # Friday after the run time -> next run is Monday
    nxt = c.next_run(datetime(2026, 10, 23, 17, 0, tzinfo=tz))
    assert (nxt.year, nxt.month, nxt.day, nxt.hour, nxt.minute) == (2026, 10, 26, 16, 10)
    # Monday before the run time -> same day
    nxt = c.next_run(datetime(2026, 10, 26, 9, 0, tzinfo=tz))
    assert nxt.day == 26


# ---------------------------------------------------------------- trading more than one thing

def test_two_symbols_split_equally_and_fill_at_own_open():
    a = flat_frame([100.0] * 30)
    b = flat_frame([50.0] * 30)
    eng, store, broker, dates = make_multi({"A": a, "B": b}, Const(1.0))
    eng.run(ReplayClock(dates))
    assert abs(broker.get_position("A") * 100 - 50_000) < 100, "half the account in A"
    assert abs(broker.get_position("B") * 50 - 50_000) < 50, "half the account in B"
    firsts = {f.symbol: f.ts for f in broker.fills}
    assert firsts["A"] == dates[6] and firsts["B"] == dates[6]
    assert abs(store.equity_series().iloc[-1] - 100_000) < 1e-6, "flat prices, no costs -> no P&L"


def test_allocation_weights():
    a, b = flat_frame([100.0] * 30), flat_frame([100.0] * 30)
    eng, _, broker, dates = make_multi({"A": a, "B": b}, Const(1.0), weights={"A": 3, "B": 1})
    eng.run(ReplayClock(dates))
    assert abs(broker.get_position("A") - 750) < 1 and abs(broker.get_position("B") - 250) < 1


def test_mixed_calendars_crypto_trades_weekends_stocks_do_not():
    days = pd.date_range("2020-01-01", periods=60, freq="D")             # 7 days a week
    crypto = pd.DataFrame({c: np.linspace(100, 160, 60) for c in ("Open", "High", "Low", "Close")}, index=days)
    wk = days[days.dayofweek < 5]                                        # Mon-Fri only
    stock = pd.DataFrame({c: np.linspace(50, 80, len(wk)) for c in ("Open", "High", "Low", "Close")}, index=wk)
    eng, store, broker, dates = make_multi({"BTC": crypto, "STK": stock}, Const(1.0))
    eng.run(ReplayClock(dates))
    assert len(store.eq) == 60, "one equity row per calendar date in the union"
    assert all(f.ts.dayofweek < 5 for f in broker.fills if f.symbol == "STK"), "stock never fills on a weekend"
    assert any(f.ts.dayofweek >= 5 for f in broker.fills if f.symbol == "BTC"), "crypto does fill on weekends"
    assert broker.get_position("STK") > 0 and broker.get_position("BTC") > 0
    eq = store.equity_series()
    assert (eq > 0).all() and not eq.isna().any(), "weekend marks carry the last stock close forward"


def test_strategy_gets_each_symbols_own_history_only():
    a, b = synthetic(300, seed=1), synthetic(300, seed=2).iloc[::2]      # B has half the bars
    seen = {"A": [], "B": []}
    class Spy:
        def __init__(self, k): self.k = k
        def target_weight(self, closes):
            seen[self.k].append((len(closes), closes.index[-1])); return 0.0
    eng, _, _, dates = make_multi({"A": a, "B": b}, {"A": Spy("A"), "B": Spy("B")})
    eng.run(ReplayClock(dates))
    for k, df in (("A", a), ("B", b)):
        assert len(seen[k]) == len(df)
        for n, last in seen[k]:
            assert last == df.index[n - 1], "history ends exactly at the bar being decided"


def test_resume_multi_symbol_matches_continuous_run():
    frames = {"A": synthetic(500, seed=7), "B": synthetic(500, seed=8)}
    strat = lambda: SmaCrossStrategy(20, 60)
    eng, store, _, dates = make_multi(frames, strat())
    eng.run(ReplayClock(dates))
    expected = store.equity_series().iloc[-1]
    bench_expected = store.bench_series().iloc[-1]

    tmp = Path(tempfile.mkdtemp()); db = tmp / "t.db"
    paths = {}
    for k, df in frames.items():
        paths[k] = str(tmp / f"{k}.csv"); df.iloc[:300].rename_axis("Date").to_csv(paths[k])
    st = SqliteStore(db); rid = st.new_run("t", "paper", "A,B", {})
    e1 = Engine(["A", "B"], CsvFeed(paths), SimBroker(100_000, 0, 0), strat(),
                RiskManager(RiskLimits(), st, rid), st, rid, Event(), 0.0)
    e1.step(frames["A"].index[299]); st.close()

    for k, df in frames.items():
        df.rename_axis("Date").to_csv(paths[k])
    st = SqliteStore(db)
    broker = SimBroker(100_000, 0, 0); broker.load_state(json.loads(st.get_kv(rid, "broker")))
    e2 = Engine(["A", "B"], CsvFeed(paths), broker, strat(), RiskManager(RiskLimits(), st, rid), st, rid, Event(), 0.0)
    e2.step(frames["A"].index[-1])
    assert abs(st.equity_series(rid).iloc[-1] - expected) < 1e-6
    assert abs(st.bench_series(rid).iloc[-1] - bench_expected) < 1e-6, "benchmark survives a restart"
    assert len(st.equity_series(rid)) == 500
    assert {h["symbol"] for h in st.holdings(rid)} == {"A", "B"}


def test_single_symbol_benchmark_is_the_close():
    df = synthetic(80, seed=3)
    eng, store, _ = make_engine(df, Const(0.0))
    eng.run(ReplayClock(df.index))
    assert np.allclose(store.bench_series().to_numpy(), df["Close"].to_numpy())


# ---------------------------------------------------------------- fractional units (crypto etc.)

def test_fractional_units_needed_for_expensive_assets():
    btc = flat_frame([60_000.0] * 20)
    whole = make_multi({"BTC": btc}, Const(1.0), broker=SimBroker(100_000, 0, 0))
    whole[0].run(ReplayClock(whole[3]))
    assert whole[2].get_position("BTC") == 1, "whole units only: 1 BTC, rest stays cash"
    frac = make_multi({"BTC": btc}, Const(1.0), broker=SimBroker(100_000, 0, 0, fractional=True))
    frac[0].run(ReplayClock(frac[3]))
    assert abs(frac[2].get_position("BTC") * 60_000 - 100_000) < 1, "fractional: fully invested"


# ---------------------------------------------------------------- shorting

def test_short_selling_profits_when_price_falls():
    df = flat_frame(list(np.linspace(100, 50, 40)))
    eng, store, broker = make_engine(df, Const(-1.0), RiskLimits(allow_short=True),
                                     broker=SimBroker(100_000, 0, 0, allow_short=True))
    eng.run(ReplayClock(df.index))
    assert broker.get_position("X") < 0, "holding a short"
    assert store.equity_series().iloc[-1] > 100_000 * 1.2, "price halved while short: big gain"
    last = df["Close"].iloc[-1]
    assert abs(broker.get_position("X")) * last <= store.equity_series().iloc[-1] * 1.05, "short sized to ~1x equity, no leverage"


def test_short_is_blocked_by_default():
    df = flat_frame(list(np.linspace(100, 50, 40)))
    eng, store, broker = make_engine(df, Const(-1.0))
    eng.run(ReplayClock(df.index))
    assert not broker.fills and broker.get_position("X") == 0
    bare = SimBroker(1000, 0, 0)                      # the broker refuses on its own, even without risk limits
    bare.place_market_order("X", -5); bare.on_bar_open(None, {"X": 10.0})
    assert bare.get_position("X") == 0 and not bare.fills


def test_flip_from_long_to_short_in_one_order():
    b = SimBroker(100_000, 0, 0, allow_short=True)
    b.place_market_order("X", 500); b.on_bar_open(None, {"X": 100.0})
    b.place_market_order("X", -1000); b.on_bar_open(None, {"X": 100.0})
    assert b.get_position("X") == -500 and len(b.fills) == 2
    assert abs(b.equity({"X": 100.0}) - 100_000) < 1e-9


def test_leverage_cap_limits_gross_exposure():
    b = SimBroker(100_000, 0, 0, allow_short=True, max_leverage=1.0)
    b.place_market_order("A", 800); b.place_market_order("B", -800)       # $80k long + $80k short = 1.6x
    b.on_bar_open(None, {"A": 100.0, "B": 100.0})
    gross = sum(abs(q) * 100 for q in b.positions.values())
    assert gross <= 100_000 + 1e-6, "second order shrinks so gross exposure stays within equity"
    assert b.get_position("A") == 800 and b.get_position("B") == -200, "the order that adds exposure is cut to the room left"


def test_cannot_buy_more_than_cash_without_leverage():
    b = SimBroker(1_000, 0, 0)
    b.place_market_order("X", 50); b.on_bar_open(None, {"X": 100.0})
    assert b.get_position("X") == 10 and b.cash == 0


def test_risk_caps_work_for_shorts_and_in_dollars():
    r = RiskManager(RiskLimits(allow_short=True, max_position_value=10_000, max_order_value=2_000), MemoryStore(), 1)
    assert r.clamp_target(-1000, 0, 100) == -20, "a short order is capped at $2k"
    assert r.clamp_target(-1000, -90, 100) == -100, "position cap is $10k either way"
    assert r.clamp_target(0, -90, 100) == 0, "covering a short is never capped"


def test_halt_flattens_shorts_too():
    p = np.concatenate([np.linspace(100, 110, 20), np.linspace(110, 200, 40)])   # price rockets while short
    df = flat_frame(list(p))
    eng, store, broker = make_engine(df, Const(-1.0), RiskLimits(allow_short=True, max_drawdown_pct=20),
                                     broker=SimBroker(100_000, 0, 0, allow_short=True))
    eng.run(ReplayClock(df.index))
    assert store.get_kv(1, "halted") and broker.get_position("X") == 0


# ---------------------------------------------------------------- config

def test_symbol_validation_and_allocation():
    assert parse_symbols("spy, btc-usd EURUSD=X ^GSPC ES=F 7203.T") == \
        ["SPY", "BTC-USD", "EURUSD=X", "^GSPC", "ES=F", "7203.T"]
    for bad in ("SPY;DROP", "../etc", "A/B", "", "SPY,SPY"):
        raises(ValueError, parse_symbols, bad)
    cfg = {"run": {"symbols": ["SPY", "QQQ"]}, "allocation": {"spy": 2, "qqq": 1}}
    assert normalize(cfg)["allocation"] == {"SPY": 2.0, "QQQ": 1.0}
    raises(ValueError, normalize, {"run": {"symbols": ["SPY", "QQQ"]}, "allocation": {"SPY": 1}})
    assert normalize({"run": {"symbol": "AAPL"}})["run"]["symbols"] == ["AAPL"], "old single-symbol configs still load"


def test_csv_path_per_symbol():
    folder = tempfile.mkdtemp()
    assert csv_path_for("data/{symbol}.csv", "BTC-USD", 3) == "data/BTC-USD.csv"
    assert csv_path_for(folder, "SPY", 3) == str(Path(folder) / "SPY.csv")
    assert csv_path_for("one.csv", "SPY", 1) == "one.csv"
    raises(ValueError, csv_path_for, "one.csv", "SPY", 2)


if __name__ == "__main__":
    tests = [v for k, v in dict(globals()).items() if k.startswith("test_")]
    for t in tests:
        t(); print("ok  ", t.__name__)
    print(f"\n{len(tests)} tests passed")
