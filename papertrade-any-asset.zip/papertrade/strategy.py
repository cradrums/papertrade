"""Strategies decide a target weight for ONE symbol: 0.0 = flat, 1.0 = fully invested in its share of
the account, -1.0 = fully short (only takes effect when [risk] allow_short = true). The engine runs
one independent strategy instance per symbol."""
import pandas as pd


class SmaCrossStrategy:
    """Long when the fast SMA is above the slow SMA, otherwise flat (or short, with short=True).

    Classic trend-following. It is a teaching example, not a proven edge.
    """

    def __init__(self, fast=50, slow=200, short=False):
        assert fast < slow, "fast window must be shorter than slow window"
        self.fast, self.slow, self.short = fast, slow, short

    def target_weight(self, closes: pd.Series):
        """Uses only data up to and including the latest close."""
        if len(closes) < self.slow:
            return None  # not enough history yet -> do nothing
        fast = closes.iloc[-self.fast:].mean()
        slow = closes.iloc[-self.slow:].mean()
        return 1.0 if fast > slow else (-1.0 if self.short else 0.0)
