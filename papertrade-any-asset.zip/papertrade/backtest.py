"""Quick backtest (in memory, nothing saved) - uses the same Engine as replay/paper.

  python backtest.py --synthetic
  python backtest.py --synthetic --symbols AAA,BBB,CCC
  python backtest.py --csv SPY.csv --symbols SPY
  python backtest.py --csv "data/{symbol}.csv" --symbols SPY,QQQ        # one CSV per symbol
  python backtest.py --yf SPY,QQQ,BTC-USD,EURUSD=X,GC=F --start 2015-01-01 --fractional
  python backtest.py --yf SPY,TLT --short                               # long/short SMA cross
"""
import argparse
from threading import Event

import pandas as pd

import metrics
from broker import SimBroker
from clock import ReplayClock
from data import csv_path_for, load_csv, load_yfinance, synthetic
from engine import Engine
from factory import parse_symbols
from feed import FrameFeed
from risk import RiskLimits, RiskManager
from state import MemoryStore
from strategy import SmaCrossStrategy


def run_backtest_ex(frames, symbols, strategy, broker, limits=None, tolerance=0.02, weights=None):
    """frames: a DataFrame (one symbol) or {symbol: DataFrame}. Returns (equity, benchmark, broker)."""
    if isinstance(frames, pd.DataFrame):
        frames = {symbols if isinstance(symbols, str) else symbols[0]: frames}
    names = list(frames)
    dates = sorted(set().union(*[df.index for df in frames.values()]))
    store = MemoryStore()
    risk = RiskManager(limits or RiskLimits(), store, 1)
    Engine(names, FrameFeed(frames), broker, strategy, risk, store, 1, Event(), tolerance, weights) \
        .run(ReplayClock(dates, 0))
    return store.equity_series(), store.bench_series(), broker


def run_backtest(df, symbol, strategy, broker, limits=None, tolerance=0.02):
    """Single-symbol convenience wrapper. Returns (equity Series, broker)."""
    eq, _, broker = run_backtest_ex(df, symbol, strategy, broker, limits, tolerance)
    return eq, broker


def buy_and_hold(df, cash):
    shares = int(cash // df["Open"].iloc[0])
    return cash - shares * df["Open"].iloc[0] + shares * df["Close"]


def main():
    p = argparse.ArgumentParser()
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--csv", help="a CSV file, a folder, or a template like data/{symbol}.csv")
    src.add_argument("--yf", metavar="SYMBOLS", help="comma separated Yahoo tickers")
    src.add_argument("--synthetic", action="store_true")
    p.add_argument("--symbols", "--symbol", dest="symbols", default=None,
                   help="comma separated (for --csv / --synthetic); default SPY / SYNTH")
    p.add_argument("--start", default="2005-01-01")
    p.add_argument("--end", default=None)
    p.add_argument("--fast", type=int, default=50)
    p.add_argument("--slow", type=int, default=200)
    p.add_argument("--cash", type=float, default=100_000)
    p.add_argument("--commission", type=float, default=0.0, help="$ per trade")
    p.add_argument("--slippage-bps", type=float, default=1.0)
    p.add_argument("--short", action="store_true", help="go short when the fast SMA is below the slow one")
    p.add_argument("--fractional", action="store_true", help="allow fractional units (crypto, forex, pricey tickers)")
    a = p.parse_args()

    if a.yf:
        symbols = parse_symbols(a.yf)
        frames = {s: load_yfinance(s, a.start, a.end) for s in symbols}
    elif a.csv:
        symbols = parse_symbols(a.symbols or "SPY")
        frames = {s: load_csv(csv_path_for(a.csv, s, len(symbols))) for s in symbols}
    else:
        symbols = parse_symbols(a.symbols or "SYNTH")
        frames = {s: synthetic(seed=i) for i, s in enumerate(symbols)}
        print("** Using SYNTHETIC random data: tests the plumbing only. **\n")

    broker = SimBroker(a.cash, a.commission, a.slippage_bps, allow_short=a.short, fractional=a.fractional)
    equity, bench, broker = run_backtest_ex(frames, symbols, SmaCrossStrategy(a.fast, a.slow, a.short), broker,
                                            RiskLimits(allow_short=a.short))
    bench = equity.iloc[0] * bench / bench.iloc[0]

    lo, hi = min(df.index[0] for df in frames.values()), max(df.index[-1] for df in frames.values())
    print(f"{', '.join(symbols)}  {lo.date()} -> {hi.date()}")
    print(f"Strategy: SMA {a.fast}/{a.slow}{' long/short' if a.short else ' long-only'}   "
          f"trades: {len(broker.fills)}   (account split equally across {len(symbols)} symbol(s))\n")
    print(metrics.table(Strategy=equity, **{"Buy & hold" if len(symbols) == 1 else "Buy & hold basket": bench}))


if __name__ == "__main__":
    main()
