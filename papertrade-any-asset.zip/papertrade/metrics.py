import math

import pandas as pd


def compute(equity: pd.Series) -> dict:
    rets = equity.pct_change().dropna()
    years = (equity.index[-1] - equity.index[0]).days / 365.25
    total = equity.iloc[-1] / equity.iloc[0] - 1
    sd = rets.std()
    per_year = len(rets) / years if years > 0 else 252   # ~252 for stocks, ~365 for crypto/mixed baskets
    return {
        "total": total,
        "cagr": (1 + total) ** (1 / years) - 1 if years > 0 and total > -1 else float("nan"),
        "max_dd": float((equity / equity.cummax() - 1).min()),
        "sharpe": float(rets.mean() / sd * math.sqrt(per_year)) if sd and sd > 0 else float("nan"),
    }


def table(**series) -> str:
    """Pretty-print metrics for one or more named equity series."""
    cols = {name: compute(s) for name, s in series.items()}
    rows = [("Total return", "total", "{:+.1%}"), ("CAGR", "cagr", "{:+.1%}"),
            ("Max drawdown", "max_dd", "{:.1%}"), ("Sharpe (rf=0)", "sharpe", "{:.2f}")]
    out = pd.DataFrame({n: {lab: f.format(c[k]) for lab, k, f in rows} for n, c in cols.items()})
    return out.to_string()
