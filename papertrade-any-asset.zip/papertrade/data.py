"""Data loaders. Every loader returns a date-indexed DataFrame (Open/High/Low/Close)."""
import os

import numpy as np
import pandas as pd

REQUIRED = ["Open", "High", "Low", "Close"]


def _clean(df: pd.DataFrame) -> pd.DataFrame:
    if getattr(df.index, "tz", None) is not None:
        df.index = df.index.tz_localize(None)
    df.index = pd.DatetimeIndex(df.index).normalize()
    df = df[~df.index.duplicated(keep="last")].sort_index()
    return df[REQUIRED].dropna()


def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=[0], index_col=0)
    df.columns = [c.strip().title() for c in df.columns]
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"CSV is missing columns: {missing}")
    return _clean(df)


def load_yfinance(symbol: str, start: str, end: str | None = None) -> pd.DataFrame:
    import yfinance as yf  # optional: pip install yfinance

    df = yf.download(symbol, start=start, end=end or None, auto_adjust=True, progress=False)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    if df.empty:
        raise RuntimeError(f"yfinance returned no data for {symbol}")
    return _clean(df)


def synthetic(n_days=2500, seed=0) -> pd.DataFrame:
    """Random-walk prices for testing the plumbing. NOT real market data."""
    rng = np.random.default_rng(seed)
    rets = rng.normal(0.0004, 0.01, n_days)
    close = 100 * np.exp(np.cumsum(rets))
    open_ = np.concatenate([[100.0], close[:-1]]) * (1 + rng.normal(0, 0.002, n_days))
    high = np.maximum(open_, close) * (1 + abs(rng.normal(0, 0.003, n_days)))
    low = np.minimum(open_, close) * (1 - abs(rng.normal(0, 0.003, n_days)))
    idx = pd.bdate_range("2010-01-01", periods=n_days)
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": close}, index=idx)


def csv_path_for(template: str, symbol: str, n_symbols: int) -> str:
    """One CSV per symbol: `data/{symbol}.csv`, or a folder (-> folder/SYMBOL.csv), or a single file for one symbol."""
    if "{symbol}" in template:
        return template.replace("{symbol}", symbol)
    if os.path.isdir(template):
        return os.path.join(template, f"{symbol}.csv")
    if n_symbols == 1:
        return template
    raise ValueError("with several symbols, data.csv_path must contain {symbol} or be a folder")


def load_all(cfg: dict, symbols: list) -> dict:
    """cfg is the [data] section: source = csv | yfinance | synthetic. Returns {symbol: DataFrame}."""
    src = cfg.get("source", "synthetic")
    start, end = cfg.get("start") or None, cfg.get("end") or None
    out = {}
    for i, sym in enumerate(symbols):
        if src == "csv":
            df = load_csv(csv_path_for(cfg["csv_path"], sym, len(symbols)))
        elif src == "yfinance":
            df = load_yfinance(sym, start or "2005-01-01", end)
        elif src == "synthetic":
            df = synthetic(seed=i)      # a different random walk per symbol
        else:
            raise ValueError(f"unknown data source: {src}")
        df = df.loc[start:end] if (start or end) else df
        if df.empty:
            raise RuntimeError(f"no data for {sym} in the requested date range")
        out[sym] = df
    return out


def load_by_source(cfg: dict, symbol: str) -> pd.DataFrame:
    return load_all(cfg, [symbol])[symbol]
