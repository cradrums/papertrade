"""Run the bot.

  python run_bot.py replay [--speed 20] [--start 2015-01-01 --end 2020-12-31] [--source synthetic]
                           [--symbols SPY,QQQ,BTC-USD,EURUSD=X]
  python run_bot.py paper                      # forward paper trading, runs until stopped

Both modes write to the SQLite database so the dashboard can show them.
"""
import argparse
import json
import logging
import signal
import sys
from datetime import datetime
from threading import Event

import metrics
from clock import LiveClock, ReplayClock
from engine import Engine
from factory import (load_config, make_limits, make_sim_broker, make_strategies, make_weights,
                     set_symbols)
from feed import make_live_feed, make_replay_feed
from risk import RiskManager
from state import SqliteStore


def _stop_event():
    stop = Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: stop.set())
    return stop


def run_replay(cfg, args):
    for key in ("start", "end", "source"):
        if getattr(args, key):
            cfg["data"][key] = getattr(args, key)
    if args.symbols:
        set_symbols(cfg, args.symbols)
    symbols = cfg["run"]["symbols"]
    label = ",".join(symbols)
    feed = make_replay_feed(cfg)
    dates = sorted(set().union(*[df.index for df in feed.frames.values()]))
    store = SqliteStore(cfg["run"]["db_path"])
    name = args.name or f"replay-{label.replace(',', '+')[:40]}-{datetime.now():%Y%m%d-%H%M%S}"
    run_id = store.new_run(name, "replay", label, cfg)
    risk = RiskManager(make_limits(cfg, disabled=args.no_risk), store, run_id)
    stop = _stop_event()
    engine = Engine(symbols, feed, make_sim_broker(cfg), make_strategies(cfg), risk, store, run_id,
                    stop, cfg["run"]["rebalance_tolerance"], make_weights(cfg))
    logging.info("replay %s: %s -> %s (%d dates), run id %d", label,
                 dates[0].date(), dates[-1].date(), len(dates), run_id)
    try:
        engine.run(ReplayClock(dates, args.speed))
    except Exception:
        store.set_status(run_id, "failed")
        raise
    store.set_status(run_id, "stopped" if stop.is_set() else "finished")

    eq = store.equity_series(run_id)
    if len(eq) > 1:
        close = store.bench_series(run_id)
        bench = eq.iloc[0] * close / close.iloc[0]
        print(f"\nRun {run_id} ({name})  symbols: {label}  trades: {len(store.fills_rows(run_id, 10**6))}")
        print(metrics.table(Strategy=eq, **{"Buy & hold": bench}))
    if risk.is_halted():
        print("\nNOTE: risk limits halted this run:", store.get_kv(run_id, "halted"))


def run_paper(cfg, args):
    symbols = cfg["run"]["symbols"]
    label = ",".join(symbols)
    store = SqliteStore(cfg["run"]["db_path"])
    name = cfg["run"]["name"]
    run_id = store.find_run(name, "paper")
    resumed = run_id is not None
    broker = make_sim_broker(cfg)
    if resumed:
        old = json.loads(store.get_run(run_id)["config"])
        if old.get("strategy") != cfg["strategy"]:
            logging.warning("strategy settings differ from when this run started; "
                            "use a new [run].name for a clean test")
        was = old.get("run", {}).get("symbols") or [old.get("run", {}).get("symbol")]
        if was != symbols:
            logging.warning("symbols changed since this run started (%s -> %s); the account is split "
                            "differently from now on. Use a new [run].name for a clean test", was, symbols)
        state = store.get_kv(run_id, "broker")
        if state:
            broker.load_state(json.loads(state))
        orphans = [s for s, q in broker.positions.items() if q and s not in symbols]
        if orphans:
            sys.exit(f"Run '{name}' still holds {orphans}, which are no longer in [run] symbols. "
                     f"Put them back in the list (or use a new [run].name) so they keep being marked and traded.")
        store.set_status(run_id, "running")
        logging.info("resuming paper run %d (%s)", run_id, name)
    else:
        run_id = store.new_run(name, "paper", label, cfg)
        logging.info("new paper run %d (%s)", run_id, name)

    risk = RiskManager(make_limits(cfg), store, run_id)
    stop = _stop_event()
    engine = Engine(symbols, make_live_feed(cfg), broker, make_strategies(cfg), risk, store, run_id,
                    stop, cfg["run"]["rebalance_tolerance"], make_weights(cfg))
    live = cfg["live"]
    try:
        engine.run(LiveClock(live["run_at"], live["timezone"]),
                   only_last_first=not resumed, raise_errors=False, log_ticks=True)
    finally:
        store.set_status(run_id, "stopped")
    logging.info("stopped")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="config.toml")
    sub = ap.add_subparsers(dest="mode", required=True)
    r = sub.add_parser("replay", help="run over historical dates as if live")
    r.add_argument("--speed", type=float, default=0, help="bars per second (0 = as fast as possible)")
    r.add_argument("--start"); r.add_argument("--end")
    r.add_argument("--symbols", help="comma separated; overrides [run] symbols for this replay")
    r.add_argument("--source", choices=["yfinance", "csv", "synthetic"])
    r.add_argument("--name"); r.add_argument("--no-risk", action="store_true")
    sub.add_parser("paper", help="forward paper trading on a schedule")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        datefmt="%Y-%m-%d %H:%M:%S")
    cfg = load_config(args.config)
    (run_replay if args.mode == "replay" else run_paper)(cfg, args)


if __name__ == "__main__":
    sys.exit(main())
