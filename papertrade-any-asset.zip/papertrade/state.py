"""Persistence. SqliteStore keeps runs on disk (bot + dashboard share it);
MemoryStore has the same API but keeps everything in RAM (fast backtests)."""
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


def fmt_ts(ts) -> str:
    ts = pd.Timestamp(ts)
    return ts.strftime("%Y-%m-%d") if ts == ts.normalize() else ts.strftime("%Y-%m-%d %H:%M:%S")


def fmt_qty(q) -> str:
    """Whole numbers stay whole; fractional quantities lose trailing zeros."""
    q = abs(float(q))
    return str(int(q)) if q == int(q) else f"{q:.6f}".rstrip("0").rstrip(".")


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


SCHEMA = """
CREATE TABLE IF NOT EXISTS runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, mode TEXT, symbol TEXT,
  config TEXT, status TEXT, started_at TEXT, ended_at TEXT);
CREATE TABLE IF NOT EXISTS equity(
  run_id INTEGER, ts TEXT, equity REAL, cash REAL, position REAL, close REAL);
CREATE TABLE IF NOT EXISTS fills(
  run_id INTEGER, ts TEXT, symbol TEXT, qty REAL, price REAL, commission REAL);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER, at TEXT, level TEXT, message TEXT);
CREATE TABLE IF NOT EXISTS kv(
  run_id INTEGER, key TEXT, value TEXT, PRIMARY KEY(run_id, key));
CREATE INDEX IF NOT EXISTS ix_equity ON equity(run_id, ts);
CREATE INDEX IF NOT EXISTS ix_fills ON fills(run_id, ts);
CREATE INDEX IF NOT EXISTS ix_events ON events(run_id, id);
"""


class SqliteStore:
    def __init__(self, path, readonly=False):
        if readonly:
            self.db = sqlite3.connect(f"file:{path}?mode=ro", uri=True, check_same_thread=False)
        else:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            self.db = sqlite3.connect(path, check_same_thread=False)
            self.db.execute("PRAGMA journal_mode=WAL")
            self.db.execute("PRAGMA synchronous=NORMAL")
            self.db.executescript(SCHEMA)
        self.db.row_factory = sqlite3.Row

    def close(self):
        self.db.close()

    def commit(self):
        self.db.commit()

    # ---- writes ----
    def new_run(self, name, mode, symbol, config) -> int:
        cur = self.db.execute(
            "INSERT INTO runs(name,mode,symbol,config,status,started_at) VALUES(?,?,?,?,?,?)",
            (name, mode, symbol, json.dumps(config), "running", now_iso()))
        self.db.commit()
        return cur.lastrowid

    def find_run(self, name, mode):
        r = self.db.execute(
            "SELECT id FROM runs WHERE name=? AND mode=? ORDER BY id DESC LIMIT 1",
            (name, mode)).fetchone()
        return r["id"] if r else None

    def set_status(self, run_id, status):
        ended = now_iso() if status in ("finished", "stopped", "failed") else None
        self.db.execute("UPDATE runs SET status=?, ended_at=? WHERE id=?", (status, ended, run_id))
        self.db.commit()

    def log(self, run_id, level, message):
        self.db.execute("INSERT INTO events(run_id,at,level,message) VALUES(?,?,?,?)",
                        (run_id, now_iso(), level, message))

    def add_equity(self, run_id, ts, equity, cash, position, close):
        self.db.execute("INSERT INTO equity VALUES(?,?,?,?,?,?)",
                        (run_id, ts, equity, cash, position, close))

    def add_fill(self, run_id, ts, symbol, qty, price, commission):
        self.db.execute("INSERT INTO fills VALUES(?,?,?,?,?,?)",
                        (run_id, ts, symbol, qty, price, commission))

    def set_kv(self, run_id, key, value):
        self.db.execute("INSERT INTO kv(run_id,key,value) VALUES(?,?,?) "
                        "ON CONFLICT(run_id,key) DO UPDATE SET value=excluded.value",
                        (run_id, key, str(value)))

    # ---- reads ----
    def get_kv(self, run_id, key, default=None):
        r = self.db.execute("SELECT value FROM kv WHERE run_id=? AND key=?", (run_id, key)).fetchone()
        return r["value"] if r else default

    def kv_all(self, run_id) -> dict:
        return {r["key"]: r["value"] for r in
                self.db.execute("SELECT key,value FROM kv WHERE run_id=? AND key NOT IN ('broker','holdings')", (run_id,))}

    def list_runs(self):
        return [dict(r) for r in self.db.execute(
            "SELECT id,name,mode,symbol,status,started_at,ended_at FROM runs ORDER BY id DESC LIMIT 200")]

    def get_run(self, run_id):
        r = self.db.execute("SELECT id,name,mode,symbol,status,started_at,ended_at,config "
                            "FROM runs WHERE id=?", (run_id,)).fetchone()
        return dict(r) if r else None

    def latest_run_id(self, mode=None):
        q, a = "SELECT id FROM runs", ()
        if mode:
            q, a = q + " WHERE mode=?", (mode,)
        r = self.db.execute(q + " ORDER BY id DESC LIMIT 1", a).fetchone()
        return r["id"] if r else None

    def equity_rows(self, run_id, max_points=1500):
        rows = [dict(r) for r in self.db.execute(
            "SELECT ts,equity,cash,position,close FROM equity WHERE run_id=? ORDER BY ts", (run_id,))]
        if len(rows) > max_points:  # downsample for the chart, always keep the last point
            step = len(rows) / max_points
            rows = [rows[int(i * step)] for i in range(max_points)] + [rows[-1]]
        return rows

    def equity_series(self, run_id) -> pd.Series:
        rows = self.db.execute("SELECT ts,equity FROM equity WHERE run_id=? ORDER BY ts", (run_id,)).fetchall()
        return pd.Series([r["equity"] for r in rows], index=pd.to_datetime([r["ts"] for r in rows]))

    def bench_series(self, run_id) -> pd.Series:
        """Buy-and-hold benchmark (the `close` column: the symbol's close, or a basket index for several)."""
        rows = self.db.execute("SELECT ts,close FROM equity WHERE run_id=? ORDER BY ts", (run_id,)).fetchall()
        return pd.Series([r["close"] for r in rows], index=pd.to_datetime([r["ts"] for r in rows]))

    def holdings(self, run_id) -> list:
        """Current positions: [{symbol, qty, price, value}], largest first."""
        raw = self.get_kv(run_id, "holdings")
        try:
            h = json.loads(raw) if raw else {}
        except ValueError:
            h = {}
        rows = [{"symbol": s, "qty": q, "price": p, "value": q * p} for s, (q, p) in h.items()]
        return sorted(rows, key=lambda r: -abs(r["value"]))

    def fills_rows(self, run_id, limit=50):
        return [dict(r) for r in self.db.execute(
            "SELECT ts,symbol,qty,price,commission FROM fills WHERE run_id=? ORDER BY ts DESC, rowid DESC LIMIT ?",
            (run_id, limit))]

    def events_rows(self, run_id, limit=100):
        return [dict(r) for r in self.db.execute(
            "SELECT at,level,message FROM events WHERE run_id=? ORDER BY id DESC LIMIT ?", (run_id, limit))]


class MemoryStore:
    """Same API as SqliteStore, nothing touches disk."""

    def __init__(self):
        self.kv, self.eq, self.fl, self.ev = {}, [], [], []

    def new_run(self, *a, **k): return 1
    def find_run(self, *a, **k): return None
    def set_status(self, *a, **k): pass
    def commit(self): pass
    def close(self): pass

    def log(self, run_id, level, message):
        if len(self.ev) < 1000:
            self.ev.append((level, message))

    def add_equity(self, run_id, ts, equity, cash, position, close):
        self.eq.append((ts, equity, close))

    def add_fill(self, run_id, ts, symbol, qty, price, commission):
        self.fl.append((ts, symbol, qty, price))

    def set_kv(self, run_id, key, value): self.kv[key] = str(value)
    def get_kv(self, run_id, key, default=None): return self.kv.get(key, default)

    def equity_series(self, run_id=1) -> pd.Series:
        return pd.Series([e[1] for e in self.eq], index=pd.to_datetime([e[0] for e in self.eq]))

    def bench_series(self, run_id=1) -> pd.Series:
        return pd.Series([e[2] for e in self.eq], index=pd.to_datetime([e[0] for e in self.eq]))
