"""Read-only web dashboard (standard library only - no extra packages).

  python dashboard.py                      # http://127.0.0.1:8080
  DASH_PASSWORD=secret python dashboard.py --host 0.0.0.0

It opens the database read-only, so it cannot place orders or change state.
Binding to anything other than localhost REQUIRES a password. Basic auth over
plain HTTP is fine on localhost or inside a VPN (WireGuard/Tailscale), but do
not expose this to the open internet.
"""
import argparse
import base64
import hmac
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from factory import load_config
from state import SqliteStore

PAGE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Trading bot</title>
<style>
:root{--bg:#fafaf9;--fg:#1c1917;--muted:#78716c;--card:#fff;--line:#e7e5e4;--accent:#2563eb;--good:#15803d;--bad:#b91c1c;--warn:#b45309}
@media (prefers-color-scheme:dark){:root{--bg:#0c0a09;--fg:#e7e5e4;--muted:#a8a29e;--card:#1c1917;--line:#292524;--accent:#60a5fa;--good:#4ade80;--bad:#f87171;--warn:#fbbf24}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:1000px;margin:0 auto;padding:16px}
header{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-bottom:14px}
h1{font-size:18px;margin:0}
select{background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:6px;padding:6px 8px;max-width:100%}
.pill{display:inline-block;padding:2px 10px;border-radius:99px;font-size:12px;font-weight:600;border:1px solid var(--line)}
.pill.ok{color:var(--good)}.pill.bad{color:var(--bad)}.pill.warn{color:var(--warn)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:10px;margin-bottom:14px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px 12px}
.card .l{color:var(--muted);font-size:12px}.card .v{font-size:18px;font-weight:600;font-variant-numeric:tabular-nums}
section{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px;margin-bottom:14px}
section h2{font-size:13px;margin:0 0 8px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.scroll{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}
th,td{text-align:left;padding:4px 8px;border-bottom:1px solid var(--line);white-space:nowrap}
td.msg{white-space:normal;word-break:break-word}
th{color:var(--muted);font-weight:500}
.good{color:var(--good)}.bad{color:var(--bad)}.muted{color:var(--muted)}
svg{width:100%;height:auto;display:block}
.banner{padding:8px 12px;border-radius:8px;margin-bottom:12px;border:1px solid var(--bad);color:var(--bad)}
</style></head><body><main>
<header><h1>Trading bot <span id="st" class="pill"></span></h1>
<div><select id="runs" aria-label="Run"></select></div></header>
<div id="banner"></div>
<div class="grid" id="cards"></div>
<section><h2>Equity <span class="muted" id="legend"></span></h2><div id="chart"></div></section>
<section><h2>Holdings</h2><div class="scroll"><table id="holdings"></table></div></section>
<section><h2>Recent fills</h2><div class="scroll"><table id="fills"></table></div></section>
<section><h2>Events</h2><div class="scroll"><table id="events"></table></div></section>
</main>
<script>
const $ = id => document.getElementById(id);
const money = n => n.toLocaleString(undefined, {maximumFractionDigits: 0});
const qty = n => Number(n).toLocaleString(undefined, {maximumFractionDigits: 6});
const pct = n => (n >= 0 ? '+' : '') + (n * 100).toFixed(1) + '%';
let runId = null, busy = false;

async function api(p){ const r = await fetch(p, {cache:'no-store'}); if(!r.ok) throw new Error(r.status); return r.json(); }
function el(tag, text, cls){ const e = document.createElement(tag); if(text !== undefined) e.textContent = text; if(cls) e.className = cls; return e; }
function fillTable(t, head, rows){
  t.replaceChildren();
  const h = el('tr'); head.forEach(x => h.append(el('th', x))); t.append(h);
  rows.forEach(r => { const tr = el('tr'); r.forEach(c => tr.append(el('td', c[0], c[1]))); t.append(tr); });
}
function card(label, value, cls){ const c = el('div', undefined, 'card'); c.append(el('div', label, 'l'), el('div', value, 'v' + (cls ? ' ' + cls : ''))); return c; }

function drawChart(rows, multi){
  const box = $('chart'); box.replaceChildren();
  if(rows.length < 2){ box.append(el('div', 'No data yet.', 'muted')); return; }
  const W = 800, H = 260, L = 62, R = 10, T = 10, B = 22;
  const eq = rows.map(r => r.equity), c0 = rows[0].close;
  const bh = rows.map(r => eq[0] * r.close / c0), all = eq.concat(bh);
  let lo = Math.min(...all), hi = Math.max(...all); if(hi === lo){ hi += 1; lo -= 1; }
  const x = i => L + (W - L - R) * i / (rows.length - 1), y = v => T + (H - T - B) * (1 - (v - lo) / (hi - lo));
  const line = (arr, dash, color) => '<polyline fill="none" stroke="' + color + '" stroke-width="1.6"' + (dash ? ' stroke-dasharray="5 4"' : '') +
    ' points="' + arr.map((v, i) => x(i).toFixed(1) + ',' + y(v).toFixed(1)).join(' ') + '"/>';
  const grid = [0, .25, .5, .75, 1].map(f => { const v = lo + (hi - lo) * f, yy = y(v);
    return '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + yy + '" y2="' + yy + '" stroke="currentColor" opacity=".12"/>' +
      '<text x="' + (L - 6) + '" y="' + (yy + 4) + '" text-anchor="end" font-size="11" fill="currentColor" opacity=".6">' + money(v) + '</text>'; }).join('');
  const lab = (i, anchor) => '<text x="' + x(i) + '" y="' + (H - 6) + '" text-anchor="' + anchor + '" font-size="11" fill="currentColor" opacity=".6">' + rows[i].ts.replace(/[<>&]/g, '') + '</text>';
  box.innerHTML = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Equity curve">' + grid +
    line(bh, true, 'var(--muted)') + line(eq, false, 'var(--accent)') + lab(0, 'start') + lab(rows.length - 1, 'end') + '</svg>';
  $('legend').textContent = ' - solid: strategy, dashed: buy & hold' + (multi ? ' (basket, same split)' : '');
}

async function loadRuns(){
  const runs = await api('/api/runs'), sel = $('runs'); sel.replaceChildren();
  runs.forEach(r => { const o = el('option', '#' + r.id + '  ' + r.mode + '  ' + r.symbol + '  ' + r.name + '  [' + r.status + ']'); o.value = r.id; sel.append(o); });
  if(runs.length){ if(runId === null || !runs.some(r => r.id == runId)) runId = runs[0].id; sel.value = runId; }
}

async function refresh(){
  if(busy) return; busy = true;
  try{
    await loadRuns();
    if(runId === null){ $('cards').replaceChildren(card('Status', 'No runs yet')); return; }
    const [info, eqRows, fills, events, holds] = await Promise.all([
      api('/api/run/' + runId), api('/api/run/' + runId + '/equity'),
      api('/api/run/' + runId + '/fills'), api('/api/run/' + runId + '/events'),
      api('/api/run/' + runId + '/holdings')]);
    const run = info.run, kv = info.kv, last = eqRows[eqRows.length - 1];
    const age = kv.heartbeat ? (Date.now() - Date.parse(kv.heartbeat)) / 1000 : null;
    let status = run.status, cls = run.status === 'running' ? 'ok' : '';
    if(kv.halted){ status = 'HALTED'; cls = 'bad'; } else if(kv.paused === '1'){ status = 'PAUSED'; cls = 'warn'; }
    else if(run.status === 'running' && age !== null && age > 180){ status = 'STALE'; cls = 'warn'; }
    else if(run.status === 'failed'){ cls = 'bad'; }
    $('st').textContent = status; $('st').className = 'pill ' + cls;
    $('banner').replaceChildren();
    if(kv.halted){ const b = el('div', 'Halted by risk limit: ' + kv.halted, 'banner'); $('banner').append(b); }
    const cards = [];
    if(last){
      const ret = last.equity / eqRows[0].equity - 1;
      let peak = 0, dd = 0; eqRows.forEach(r => { peak = Math.max(peak, r.equity); dd = Math.min(dd, r.equity / peak - 1); });
      cards.push(card('Equity', '$' + money(last.equity)), card('Return', pct(ret), ret >= 0 ? 'good' : 'bad'),
        card('Max drawdown', pct(dd), dd < -0.1 ? 'bad' : ''), card('Open positions', String(holds.filter(h => h.qty).length)),
        card('Cash', '$' + money(last.cash)), card('Last bar', last.ts));
    }
    cards.push(card('Heartbeat', age === null ? '-' : (age < 90 ? Math.round(age) + 's ago' : Math.round(age / 60) + ' min ago')));
    $('cards').replaceChildren(...cards);
    drawChart(eqRows, run.symbol.indexOf(',') >= 0);
    const eqNow = last ? last.equity : 0;
    fillTable($('holdings'), ['Symbol', 'Side', 'Units', 'Price', 'Value', '% of equity'],
      holds.filter(h => h.qty).map(h => [[h.symbol], [h.qty > 0 ? 'LONG' : 'SHORT', h.qty > 0 ? 'good' : 'bad'],
        [qty(Math.abs(h.qty))], [h.price.toFixed(2)], ['$' + money(h.value)], [eqNow ? pct(h.value / eqNow) : '-']]));
    fillTable($('fills'), ['Date', 'Side', 'Qty', 'Symbol', 'Price'],
      fills.map(f => [[f.ts], [f.qty > 0 ? 'BUY' : 'SELL', f.qty > 0 ? 'good' : 'bad'], [qty(Math.abs(f.qty))], [f.symbol], [f.price.toFixed(2)]]));
    fillTable($('events'), ['Time (UTC)', 'Level', 'Message'],
      events.map(e => [[e.at.replace('T', ' ').replace('Z', ''), 'muted'], [e.level, e.level === 'ERROR' ? 'bad' : ''], [e.message, 'msg']]));
  } catch(e){ $('st').textContent = 'error'; $('st').className = 'pill bad'; }
  finally { busy = false; }
}
$('runs').addEventListener('change', e => { runId = e.target.value; refresh(); });
refresh(); setInterval(refresh, 5000);
</script></body></html>
"""


class Handler(BaseHTTPRequestHandler):
    server_version = "BotDash"

    def log_message(self, *args):  # keep the console quiet
        pass

    def _send(self, code, body, ctype="application/json", extra=None):
        data = body if isinstance(body, bytes) else body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy",
                         "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def _authorized(self) -> bool:
        pw = os.environ.get("DASH_PASSWORD")
        if not pw:
            return True
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                _, _, given = base64.b64decode(h[6:]).decode().partition(":")
                return hmac.compare_digest(given.encode(), pw.encode())
            except Exception:
                return False
        return False

    def do_GET(self):
        if not self._authorized():
            return self._send(401, "Authentication required", "text/plain",
                              {"WWW-Authenticate": 'Basic realm="bot"'})
        url = urlparse(self.path)
        parts = [p for p in url.path.split("/") if p]
        q = parse_qs(url.query)
        if not parts:
            return self._send(200, PAGE, "text/html")
        if parts[0] != "api":
            return self._send(404, "not found", "text/plain")
        try:
            store = SqliteStore(self.server.db_path, readonly=True)
        except Exception:
            return self._send(200, "[]" if parts[1:] == ["runs"] else "{}")
        try:
            if parts[1:] == ["runs"]:
                return self._send(200, json.dumps(store.list_runs()))
            if len(parts) >= 3 and parts[1] == "run" and parts[2].isdigit():
                rid, sub = int(parts[2]), parts[3] if len(parts) > 3 else ""
                lim = max(1, min(int((q.get("limit") or ["100"])[0]), 1000))
                if sub == "":
                    run = store.get_run(rid)
                    if not run:
                        return self._send(404, '{"error":"no such run"}')
                    run.pop("config", None)
                    return self._send(200, json.dumps({"run": run, "kv": store.kv_all(rid)}))
                if sub == "equity":
                    return self._send(200, json.dumps(store.equity_rows(rid)))
                if sub == "holdings":
                    return self._send(200, json.dumps(store.holdings(rid)))
                if sub == "fills":
                    return self._send(200, json.dumps(store.fills_rows(rid, min(lim, 50))))
                if sub == "events":
                    return self._send(200, json.dumps(store.events_rows(rid, lim)))
            return self._send(404, '{"error":"not found"}')
        finally:
            store.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8080)
    a = ap.parse_args()

    if a.host not in ("127.0.0.1", "localhost", "::1") and not os.environ.get("DASH_PASSWORD"):
        sys.exit("Refusing to listen on a non-local address without DASH_PASSWORD set.")
    httpd = ThreadingHTTPServer((a.host, a.port), Handler)
    httpd.db_path = load_config(a.config)["run"]["db_path"]
    print(f"Dashboard on http://{a.host}:{a.port}  (read-only, db: {httpd.db_path})")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
