"""Builds the engine's parts from config.toml."""
import copy
import re
import tomllib

from broker import SimBroker
from risk import RiskLimits
from strategy import SmaCrossStrategy

DEFAULTS = {
    "run": {"name": "bot", "symbol": "SPY", "db_path": "data/bot.db", "rebalance_tolerance": 0.02},
    "data": {"source": "synthetic", "csv_path": "", "start": "", "end": ""},
    "strategy": {"name": "sma_cross", "fast": 50, "slow": 200},
    "sim": {"starting_cash": 100000, "commission_per_trade": 0.0, "slippage_bps": 1.0, "fractional": False},
    "risk": {},
    "allocation": {},
    "live": {"run_at": "16:10", "timezone": "America/New_York"},
}

# Yahoo-style tickers: SPY, BRK-B, BTC-USD, EURUSD=X, ES=F, ^GSPC, 7203.T, 0700.HK ...
SYMBOL_RE = re.compile(r"^[A-Z0-9^][A-Z0-9.^=\-_]{0,19}$")


def parse_symbols(value) -> list:
    """Accepts a list or a comma/space separated string. Returns validated, upper-cased, unique symbols."""
    if isinstance(value, str):
        value = [v for v in re.split(r"[,\s]+", value) if v]
    syms = [str(v).strip().upper() for v in value]
    if not syms:
        raise ValueError("no symbols configured: set [run] symbols = [\"SPY\", \"BTC-USD\"]")
    for s in syms:
        if not SYMBOL_RE.match(s):
            raise ValueError(f"invalid symbol {s!r}: use letters, digits and . ^ = - _ only (max 20 chars)")
    if len(set(syms)) != len(syms):
        raise ValueError(f"duplicate symbols in {syms}")
    return syms


def normalize(cfg: dict) -> dict:
    """Fills in run.symbols (from `symbols` or the old single `symbol`) and checks [allocation]."""
    run = cfg["run"]
    run["symbols"] = parse_symbols(run.get("symbols") or run.get("symbol") or "SPY")
    run["symbol"] = run["symbols"][0]               # kept for anything that still reads the old key
    alloc = {str(k).upper(): float(v) for k, v in (cfg.get("allocation") or {}).items()}
    if alloc:
        missing = [s for s in run["symbols"] if s not in alloc]
        extra = [s for s in alloc if s not in run["symbols"]]
        if missing or extra:
            raise ValueError(f"[allocation] must list exactly the symbols being traded "
                             f"(missing: {missing}, not traded: {extra})")
        if any(v < 0 for v in alloc.values()) or sum(alloc.values()) <= 0:
            raise ValueError("[allocation] weights must be >= 0 and not all zero")
    cfg["allocation"] = alloc
    return cfg


def set_symbols(cfg: dict, value) -> dict:
    cfg["run"]["symbols"] = parse_symbols(value)
    return normalize(cfg)


def load_config(path: str) -> dict:
    with open(path, "rb") as f:
        user = tomllib.load(f)
    cfg = copy.deepcopy(DEFAULTS)
    for section, values in user.items():
        cfg.setdefault(section, {}).update(values)
    return normalize(cfg)


def make_strategy(cfg: dict):
    s = cfg["strategy"]
    if s["name"] == "sma_cross":
        return SmaCrossStrategy(int(s["fast"]), int(s["slow"]), short=bool(s.get("short", False)))
    raise ValueError(f"unknown strategy: {s['name']}")


def make_strategies(cfg: dict) -> dict:
    """One independent strategy instance per symbol (strategies may keep state)."""
    return {sym: make_strategy(cfg) for sym in cfg["run"]["symbols"]}


def make_weights(cfg: dict):
    """Share of the account given to each symbol, or None for an equal split."""
    return dict(cfg["allocation"]) or None


def make_sim_broker(cfg: dict) -> SimBroker:
    s, r = cfg["sim"], cfg["risk"]
    return SimBroker(s["starting_cash"], s["commission_per_trade"], s["slippage_bps"],
                     allow_short=bool(r.get("allow_short", False)),
                     max_leverage=float(r.get("max_leverage") or 1.0),
                     fractional=bool(s.get("fractional", False)))


def make_limits(cfg: dict, disabled=False) -> RiskLimits:
    r = cfg["risk"]
    if disabled:  # --no-risk drops the loss/size limits but keeps the shorting and leverage rules
        r = {k: r[k] for k in ("allow_short", "max_leverage") if k in r}
    return RiskLimits.from_dict(r)
