"""Hard limits that sit between the strategy and the broker.

The strategy proposes a target position; the RiskManager has the final say.
A limit set to 0 (or omitted) is disabled (except max_leverage, where 0 means 1.0).
Position limits apply per symbol; halts apply to the whole account.
"""
import math
from dataclasses import dataclass


@dataclass
class RiskLimits:
    max_position_value: float = 0.0   # max $ held in any ONE symbol (long or short)
    max_order_shares: float = 0       # max units in a single order that ADDS exposure (fat-finger guard)
    max_order_value: float = 0.0      # same, in $ (makes more sense when symbols have very different prices)
    max_daily_loss_pct: float = 0.0   # halt if equity falls this % in one bar
    max_drawdown_pct: float = 0.0     # halt if equity falls this % below its peak
    flatten_on_halt: bool = True      # close everything when halted
    allow_short: bool = False         # may the bot hold negative positions?
    max_leverage: float = 1.0         # gross exposure / equity ceiling (1.0 = no leverage)

    @classmethod
    def from_dict(cls, d: dict) -> "RiskLimits":
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


class RiskManager:
    def __init__(self, limits: RiskLimits, store, run_id):
        self.limits, self.store, self.run_id = limits, store, run_id
        self.on_event = lambda level, msg: None  # the engine plugs its logger in here
        peak = store.get_kv(run_id, "peak")
        prev = store.get_kv(run_id, "prev_equity")
        self.peak = float(peak) if peak else None
        self.prev = float(prev) if prev else None

    # --- state flags (also editable from ctl.py) ---
    def is_paused(self) -> bool:
        return self.store.get_kv(self.run_id, "paused", "0") == "1"

    def is_halted(self) -> bool:
        return bool(self.store.get_kv(self.run_id, "halted", ""))

    def halt(self, reason: str):
        if not self.is_halted():
            self.store.set_kv(self.run_id, "halted", reason)
            self.on_event("ERROR", f"HALTED: {reason}")

    def update(self, equity: float):
        """Call once per bar with the latest equity."""
        L = self.limits
        self.peak = equity if self.peak is None else max(self.peak, equity)
        if L.max_daily_loss_pct and self.prev:
            chg = (equity / self.prev - 1) * 100
            if chg <= -L.max_daily_loss_pct:
                self.halt(f"one-bar loss {chg:.1f}% hit the {L.max_daily_loss_pct}% limit")
        if L.max_drawdown_pct:
            dd = (equity / self.peak - 1) * 100
            if dd <= -L.max_drawdown_pct:
                self.halt(f"drawdown {dd:.1f}% hit the {L.max_drawdown_pct}% limit")
        self.prev = equity
        self.store.set_kv(self.run_id, "peak", self.peak)
        self.store.set_kv(self.run_id, "prev_equity", equity)

    def clamp_target(self, desired: float, current: float, price: float) -> float:
        """Return the position (in units) the bot is actually allowed to aim for.

        `desired` is the raw (unrounded) target; the engine rounds the result to a tradable lot.
        """
        L = self.limits
        if self.is_paused():
            return current
        if not L.allow_short:
            desired = max(desired, 0.0)
        if self.is_halted():
            if L.flatten_on_halt:
                desired = 0.0
            else:  # may reduce, never add or flip
                desired = min(max(desired, min(current, 0.0)), max(current, 0.0))
        if L.max_position_value:
            cap = L.max_position_value / price
            desired = max(-cap, min(desired, cap))
        delta = desired - current
        cap_units = min([c for c in (L.max_order_shares, L.max_order_value / price if L.max_order_value else 0)
                         if c] or [0])
        if cap_units and delta:
            # closing existing exposure is never capped; only the part that opens new exposure is
            if current > 0 and delta < 0:
                closing = max(delta, -current)
            elif current < 0 and delta > 0:
                closing = min(delta, -current)
            else:
                closing = 0.0
            opening = delta - closing
            if abs(opening) > cap_units:
                opening = math.copysign(cap_units, opening)
            desired = current + closing + opening
        return desired
