"""Data feeds. A feed answers one question: 'what bars exist up to time ts?'

It returns {symbol: DataFrame}. Because feeds only ever return bars <= ts, strategy code cannot
peek at the future. Different symbols may have different calendars (stocks skip weekends, crypto
does not); the engine copes with that.
"""
import time
from abc import ABC, abstractmethod
from datetime import datetime, timezone

import pandas as pd

from data import csv_path_for, load_csv, load_all, load_yfinance


class Feed(ABC):
    @abstractmethod
    def bars_until(self, ts) -> dict:
        """{symbol: DataFrame of bars with index <= ts}"""


class FrameFeed(Feed):
    """Static history held in memory (used for replay / backtests)."""

    def __init__(self, frames: dict):
        if not isinstance(frames, dict):
            raise TypeError("FrameFeed needs a {symbol: DataFrame} dict")
        self.frames = frames

    def bars_until(self, ts):
        return {s: df.loc[:ts] for s, df in self.frames.items()}


class CsvFeed(Feed):
    """Re-reads CSVs on every call, so an external job can keep appending rows. paths = {symbol: path}."""

    def __init__(self, paths: dict):
        if not isinstance(paths, dict):
            raise TypeError("CsvFeed needs a {symbol: path} dict")
        self.paths = paths

    def bars_until(self, ts):
        return {s: load_csv(p).loc[:ts] for s, p in self.paths.items()}


def _drop_forming_bar(df: pd.DataFrame) -> pd.DataFrame:
    """24/7 markets (crypto) have a bar for the current UTC day that is still forming. Drop it.

    A symbol counts as 24/7 if its recent history contains weekend bars.
    """
    if len(df) and (df.index[-60:].dayofweek >= 5).any():
        today = pd.Timestamp(datetime.now(timezone.utc).date())
        return df[df.index < today]
    return df


class YFinanceFeed(Feed):
    """Downloads daily bars from Yahoo (cached briefly). Free and unofficial."""

    def __init__(self, symbols, start: str, ttl: float = 300.0):
        self.symbols = [symbols] if isinstance(symbols, str) else list(symbols)
        self.start, self.ttl = start, ttl
        self._cache, self._at = None, 0.0

    def bars_until(self, ts):
        if self._cache is None or time.time() - self._at > self.ttl:
            self._cache = {s: _drop_forming_bar(load_yfinance(s, self.start)) for s in self.symbols}
            self._at = time.time()
        return {s: df.loc[:ts] for s, df in self._cache.items()}


def make_replay_feed(cfg: dict) -> FrameFeed:
    return FrameFeed(load_all(cfg["data"], cfg["run"]["symbols"]))


def make_live_feed(cfg: dict) -> Feed:
    d, symbols = cfg["data"], cfg["run"]["symbols"]
    if d["source"] == "csv":
        return CsvFeed({s: csv_path_for(d["csv_path"], s, len(symbols)) for s in symbols})
    if d["source"] == "yfinance":
        return YFinanceFeed(symbols, d.get("start") or "2005-01-01")
    raise ValueError("paper mode needs data.source = 'csv' or 'yfinance'")
