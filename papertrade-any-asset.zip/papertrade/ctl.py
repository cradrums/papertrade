"""Control a run from the command line.

  python ctl.py runs
  python ctl.py status [--run ID]
  python ctl.py pause|resume|clear-halt [--run ID]
  python ctl.py tail [--run ID] [-n 30]

Changes are picked up the next time the bot processes a bar. The default run is
the most recent paper run (or the most recent run of any kind).
"""
import argparse

from factory import load_config
from state import SqliteStore


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("cmd", choices=["runs", "status", "pause", "resume", "clear-halt", "tail"])
    ap.add_argument("--run", type=int)
    ap.add_argument("-n", type=int, default=30)
    a = ap.parse_args()

    store = SqliteStore(load_config(a.config)["run"]["db_path"])
    if a.cmd == "runs":
        for r in store.list_runs():
            print(f"{r['id']:>4}  {r['mode']:<7} {r['status']:<9} {r['symbol']:<6} {r['name']}")
        return
    rid = a.run or store.latest_run_id("paper") or store.latest_run_id()
    if rid is None:
        raise SystemExit("no runs yet")

    if a.cmd == "status":
        run, kv = store.get_run(rid), store.kv_all(rid)
        print(f"run {rid}: {run['name']} ({run['mode']}) status={run['status']}")
        for k in ("last_ts", "heartbeat", "paused", "halted"):
            print(f"  {k}: {kv.get(k, '-')}")
        rows = store.equity_rows(rid, 10**6)
        if rows:
            print(f"  equity: {rows[-1]['equity']:,.2f}   cash: {rows[-1]['cash']:,.2f}")
        for h in store.holdings(rid):
            if h["qty"]:
                print(f"  {h['symbol']:<10} {h['qty']:>14,.6g} @ {h['price']:,.4f} = {h['value']:>14,.2f}")
    elif a.cmd == "pause":
        store.set_kv(rid, "paused", "1"); store.commit(); print("paused: no new orders will be placed")
    elif a.cmd == "resume":
        store.set_kv(rid, "paused", "0"); store.commit(); print("resumed")
    elif a.cmd == "clear-halt":
        store.set_kv(rid, "halted", ""); store.commit(); print("halt cleared")
    elif a.cmd == "tail":
        for e in reversed(store.events_rows(rid, a.n)):
            print(e["at"], e["level"], e["message"])


if __name__ == "__main__":
    main()
